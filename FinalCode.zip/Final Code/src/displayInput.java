import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class displayInput {
    private static JTextField inputField;
    private static String start;

    public String getStart() {
        return start;
    }
    public static String getUserInput() {
        //System.out.println(inputField);

        if (inputField != null){
            System.out.println(inputField);
            return inputField.getText().trim();
        }
        else{
            return "";
        }

    }
    public void initialize(){
        //JFrame for input
        JFrame inputFrame = new JFrame("Knights Tour Solver");
        inputFrame.setSize(800,500);
        inputFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inputFrame.setLayout(new GridBagLayout());

        //label for titlle
        JLabel title = new JLabel("Welcome to the Knight's Tour Solver Program", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 25));

        //label for heading
        JLabel inputDialogue = new JLabel("Enter your starting space (e.g A1, C5 etc)", SwingConstants.CENTER);
        inputDialogue.setFont(new Font("Arial", Font.BOLD, 18));

        //input field
        inputField = new JTextField(10);
        inputField.setFont(new Font("Arial", Font.PLAIN, 16));
        inputField.setHorizontalAlignment(JTextField.CENTER);

        //clickable button to solve the tour
        JButton submitButton = new JButton("Solve Tour");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));

        //result label - initially empty
        JLabel resultLabel = new JLabel("");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 16));

        //button click event
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userInput = inputField.getText().trim();
                if (userInput.matches("[A-H][1-8]")) { //validate input
                    start = userInput;
                    resultLabel.setText("Starting position: " + userInput);
                    synchronized (displayInput.this) {
                        displayInput.this.notify();  //tell the main thread that the input is valid
                    }
                    //start = userInput;
                } else {
                    resultLabel.setText("Invalid input! Please enter a valid chessboard position.");
                }
            }
        });

        //GridBagConstraints to move content around the frame

        //GridBagConstraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(-300, 0, 0, 0);

        //GridBagConstraints
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.gridx = 0;
        gbc2.gridy = 0;
        gbc2.insets = new Insets(-200, 0, 0, 0);

        //GridBagConstraints
        GridBagConstraints gbc3 = new GridBagConstraints();
        gbc3.gridx = 0;
        gbc3.gridy = 2;
        gbc3.fill = GridBagConstraints.HORIZONTAL;
        gbc3.insets = new Insets(5, 0, 10, 0);

        //GridBagConstraints
        GridBagConstraints gbc4 = new GridBagConstraints();
        gbc4.gridx = 0;
        gbc4.gridy = 3;
        gbc4.insets = new Insets(10, 0, 10, 0);

        //GridBagConstraints
        GridBagConstraints gbc5 = new GridBagConstraints();
        gbc5.gridx = 0;
        gbc5.gridy = 4;
        gbc5.gridwidth = 2;
        gbc5.insets = new Insets(10, 0, 10, 0);

        //add components to the frame
        inputFrame.add(title, gbc);
        inputFrame.add(inputDialogue, gbc2);
        inputFrame.add(inputField, gbc3);
        inputFrame.add(submitButton, gbc4);
        inputFrame.add(resultLabel, gbc5);
        //inputFrame.add(scrollPane);


        inputFrame.setLocationRelativeTo(null);
        inputFrame.setVisible(true);
    }

}
