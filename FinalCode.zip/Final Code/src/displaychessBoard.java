import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.awt.Color;
import java.util.Map;

public class displaychessBoard extends JPanel {

    //Static variables
    public static String primaryColour;
    public static String secondaryColour;
    public static int step = 0;
    private static int knightX = 0;  //Knight's current X coordinate
    private static int knightY = 0;  //Knight's current Y coordinate
    public static ArrayList allBlackspaces = new ArrayList<>();

    //Public variables
    public ArrayList<String> moves;
    public Integer delay;
    public boolean showAll = false;
    public boolean takeNextStep = false;
    public boolean takeNextStepBackwards = false;
    public ArrayList allCurrentSteps;
    public boolean deleteAllBool = false;
    public boolean knightMovementTime = false;

    //Private  variables
    private int knightMovementStep = 0;  //Knight's current movement step
    public int delayMove = 0;

    //constructor
    public displaychessBoard(ArrayList inputArray, int Inputdelay, String firstC, String secondC) {
        moves = inputArray;
        delay = Inputdelay;
        primaryColour = firstC;
        secondaryColour = secondC;
        System.out.println("INPUT DELAY IS" + delay);
    }

    //getters and setters
    public String getFirst() {
        String first = moves.get(0);
        char fileChar = first.charAt(0); //'E'
        int rank = Character.getNumericValue(first.charAt(1)); //2
        int y = 9 - rank; //9 - 2 = 7
        //System.out.println("HERE");
        String correctedFirst = String.valueOf(fileChar) + String.valueOf(y);
        return correctedFirst;
    }

    public static String getPrimaryColour() {
        return primaryColour;
    }

    public static String getSecondaryColour() {
        return secondaryColour;
    }

    public int getdelayMove() {
        return delayMove;
    }

    public void setDelayMove(int x) {
        this.delayMove = x;
    }

    //Helper method
    public static Color getColorFromName(String colorName) {
        Map<String, Color> colorMap = Map.of(
                "black", Color.black,
                "white", Color.white,
                "red", Color.red,
                "blue", Color.blue,
                "orange", Color.orange,
                "yellow", Color.yellow
        );

        return colorMap.getOrDefault(colorName.toLowerCase(), Color.BLACK); //default to black if not found
    }
    public static int getStep(){
        return step;
    }

    public static void increaseStep(){
        step = step + 1;
    }

    public static void maxStep(){
        step = 64;
    }

    public static void decreaseStep(){
        step = step - 1;
    }

    public static void resetStep(){
        step = 0;
    }

    public static ArrayList getAllCurrentSteps(){
        return getAllCurrentSteps();
    }

    //public static Image knightImage = new ImageIcon("knight.png").getImage();
    public static Image knightImage = new ImageIcon("C:\\Users\\mikey\\Documents\\Knight's Tour\\test\\knightFour.png").getImage();
    //////////////////////////////////////



    public int[] getCoordsFromSquare(String square, int boardWidth, int boardHeight) {
        int squareSize = 64;
        int boardSize = squareSize * 8;
        int startX = (boardWidth - boardSize) / 2;
        int startY = ((boardHeight - boardSize) / 2) + 25;

        if (square.length() != 2) return null;

        char colChar = square.charAt(0); //A–H
        char rowChar = square.charAt(1); //1–8

        int col = colChar - 'A'; //A = 0
        int row = 8 - Character.getNumericValue(rowChar); //1 (bottom) -> 7, 8 (top) -> 0

        int xCoord = startX + col * squareSize + squareSize / 2;
        int yCoord = startY + row * squareSize + squareSize / 2;

        return new int[]{xCoord, yCoord};
    }





    //A hashmap which stores the coordinates of where each tile is
    public static HashMap allCoords(){
        //May need to be edited for different sized windows
        int[] A1 = {158,168};
        int[] B1 = {220,168};
        int[] C1 = {284,168};
        int[] D1 = {348,168};
        int[] E1 = {412,168};
        int[] F1 = {476,168};
        int[] G1 = {540,168};
        int[] H1 = {604,168};
        //
        int[] A2 = {158,232};
        int[] B2 = {220,232};
        int[] C2 = {284,232};
        int[] D2 = {348,232};
        int[] E2 = {412,232};
        int[] F2 = {476,232};
        int[] G2 = {540,232};
        int[] H2 = {604,232};
        //
        int[] A3 = {158,296};
        int[] B3 = {220,296};
        int[] C3 = {284,296};
        int[] D3 = {348,296};
        int[] E3 = {412,296};
        int[] F3 = {476,296};
        int[] G3 = {540,296};
        int[] H3 = {604,296};
        //updated new
        int[] A4 = {158,360};
        int[] B4 = {220,360};
        int[] C4 = {284,360};
        int[] D4 = {348,360};
        int[] E4 = {412,360};
        int[] F4 = {476,360};
        int[] G4 = {540,360};
        int[] H4 = {604,360};
        //updated new
        int[] A5 = {158,424};
        int[] B5 = {220,424};
        int[] C5 = {284,424};
        int[] D5 = {348,424};
        int[] E5 = {412,424};
        int[] F5 = {476,424};
        int[] G5 = {540,424};
        int[] H5 = {604,424};
        //
        int[] A6 = {158,488};
        int[] B6 = {220,488};
        int[] C6 = {284,488};
        int[] D6 = {348,488};
        int[] E6 = {412,488};
        int[] F6 = {476,488};
        int[] G6 = {540,488};
        int[] H6 = {604,488};
        //updated new
        int[] A7 = {158,552};
        int[] B7 = {220,552};
        int[] C7 = {284,552};
        int[] D7 = {348,552};
        int[] E7 = {412,552};
        int[] F7 = {476,552};
        int[] G7 = {540,552};
        int[] H7 = {604,552};
        //updated new
        int[] A8 = {158,616};
        int[] B8 = {220,616};
        int[] C8 = {284,616};
        int[] D8 = {348,616};
        int[] E8 = {412,616};
        int[] F8 = {476,616};
        int[] G8 = {540,616};
        int[] H8 = {604,616};//468, 488 //X = X + (64*2) + 8

        HashMap<String, int[]> arrayMap = new HashMap<>();
        arrayMap.put("A1", A1);
        arrayMap.put("B1", B1);
        arrayMap.put("C1", C1);
        arrayMap.put("D1", D1);
        arrayMap.put("E1", E1);
        arrayMap.put("F1", F1);
        arrayMap.put("G1", G1);
        arrayMap.put("H1", H1);

        arrayMap.put("A2", A2);
        arrayMap.put("B2", B2);
        arrayMap.put("C2", C2);
        arrayMap.put("D2", D2);
        arrayMap.put("E2", E2);
        arrayMap.put("F2", F2);
        arrayMap.put("G2", G2);
        arrayMap.put("H2", H2);

        arrayMap.put("A3", A3);
        arrayMap.put("B3", B3);
        arrayMap.put("C3", C3);
        arrayMap.put("D3", D3);
        arrayMap.put("E3", E3);
        arrayMap.put("F3", F3);
        arrayMap.put("G3", G3);
        arrayMap.put("H3", H3);

        arrayMap.put("A4", A4);
        arrayMap.put("B4", B4);
        arrayMap.put("C4", C4);
        arrayMap.put("D4", D4);
        arrayMap.put("E4", E4);
        arrayMap.put("F4", F4);
        arrayMap.put("G4", G4);
        arrayMap.put("H4", H4);

        arrayMap.put("A5", A5);
        arrayMap.put("B5", B5);
        arrayMap.put("C5", C5);
        arrayMap.put("D5", D5);
        arrayMap.put("E5", E5);
        arrayMap.put("F5", F5);
        arrayMap.put("G5", G5);
        arrayMap.put("H5", H5);

        arrayMap.put("A6", A6);
        arrayMap.put("B6", B6);
        arrayMap.put("C6", C6);
        arrayMap.put("D6", D6);
        arrayMap.put("E6", E6);
        arrayMap.put("F6", F6);
        arrayMap.put("G6", G6);
        arrayMap.put("H6", H6);

        arrayMap.put("A7", A7);
        arrayMap.put("B7", B7);
        arrayMap.put("C7", C7);
        arrayMap.put("D7", D7);
        arrayMap.put("E7", E7);
        arrayMap.put("F7", F7);
        arrayMap.put("G7", G7);
        arrayMap.put("H7", H7);

        arrayMap.put("A8", A8);
        arrayMap.put("B8", B8);
        arrayMap.put("C8", C8);
        arrayMap.put("D8", D8);
        arrayMap.put("E8", E8);
        arrayMap.put("F8", F8);
        arrayMap.put("G8", G8);
        arrayMap.put("H8", H8);
        return arrayMap;
    }


    //A function which when called adds in a single move from the completed Knight's Tour
    private void nextStep(Graphics g, ArrayList moves, JPanel knightMovement){

        //retrieve the next step needed
        int numToStep = getStep();
        //System.out.println("STEP IS:"+step);
        //HashMap arrayMap = allCoords();
        g.setFont(new Font("Arial", Font.BOLD, 20));

        //for each number up to the step required...
        for (int i = 0; i <= numToStep; i++){

            //Pass in a coordinate in the form "A1"
            //int[] retrievedCoords = (int[]) arrayMap.get(moves.get(i));
            int[] retrievedCoords = getCoordsFromSquare((String) moves.get(i), knightMovement.getWidth(), knightMovement.getHeight());
            if (retrievedCoords == null) {
                System.err.println("Error: Coordinates not found for key: ");
                return;
            }

            //extract exact coordinates
            int xCoord = retrievedCoords[0];
            knightX = retrievedCoords[0];
            int yCoord = retrievedCoords[1];
            knightY = retrievedCoords[1];


            int number = i + 1;

            //for each one
            for (int j=0; j <= allBlackspaces.size()-1; j++){
                if (moves.get(i).equals(allBlackspaces.get(j))){
                    String colour = getSecondaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                    break;
                }
                else{
                    String colour = getPrimaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                }
            }

            knightMovementTime = true;

            //add in the new number at the right coordinates
            g.drawString(String.valueOf(number), xCoord, yCoord);

            if (i == 0){//then first step and need to draw on Knight piece
                System.out.println(knightImage+"KNIGHT IMAGE");
                //System.out.println("KNIGHT IMAGE: " + knightImage.getWidth(null) + "x" + knightImage.getHeight(null));
                //g.drawImage(knightImage, xCoord-10, yCoord-35, 38, 62, null);
            }
            else{//need to move image to new coordinates
                //System.out.println("Need to move to new coords");
                int xCoordNEW = retrievedCoords[0];
                int yCoordNEW = retrievedCoords[1];
                //move along 2 and then across one

                //get coords for down 2
                int[] retrievedCoordsPrev = getCoordsFromSquare((String) moves.get(i-1), knightMovement.getWidth(), knightMovement.getHeight());
                ArrayList retrievedNumsPrev = new ArrayList<>();
                int xCoordOLD = retrievedCoordsPrev[0];
                int yCoordOLD = retrievedCoordsPrev[1];

                //System.out.println("New coords are:"+xCoordNEW+yCoordNEW+"");

                int changeInX = Math.abs(xCoordNEW-xCoordOLD);
                int changeInY = Math.abs(yCoordNEW-yCoordOLD);
                //System.out.println("change in x:"+changeInX);
                //System.out.println("change in y"+changeInY);

            }
        }
        //makes sure that the number to add in does not exceed 64
        if (numToStep <= 62){
            increaseStep();
        }
        knightMovement.repaint();
    }


    //A function which when called removes a single move from the completed Knight's Tour
    private void takeStepBack(Graphics g, ArrayList moves){
        int numToRemove = getStep();
        System.out.println("Step to remove"+numToRemove);
        HashMap arrayMap = allCoords();

        g.setFont(new Font("Arial", Font.BOLD, 20));
        Color gold = new Color(255, 215, 0);
        g.setColor(Color.darkGray);

        int x = 0;
        int y = 0;

        for (int i = 0; i <= numToRemove-2; i++){
            int[] retrievedCoords = getCoordsFromSquare((String) moves.get(i), getWidth(), getHeight());
            if (retrievedCoords == null) {
                System.err.println("Error: Coordinates not found for key: ");
                return;  //avoid further execution if no coordinates are found
            }
            ArrayList retrievedNums = new ArrayList<>();
            for (int num : retrievedCoords) {
                retrievedNums.add(num);
                //System.out.println(num);
            }
            int xCoord = (int) retrievedNums.get(0);
            int yCoord = (int) retrievedNums.get(1);
            int number = i + 1;

            for (int j=0; j <= allBlackspaces.size()-1; j++){
                //System.out.println(moves.get(step));
                //System.out.println(allBlackspaces.get(i));
                if (moves.get(i).equals(allBlackspaces.get(j))){
                    //System.out.println("//////////////////////////////////////////////////////////");
                    String colour = getSecondaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                    break;
                }
                else{
                    String colour = getPrimaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                }
            }

            g.drawString(String.valueOf(number), xCoord, yCoord);

        }

        //makes sure that doesnt try to do more than 64 moves in total
        if (numToRemove == 0){
            System.out.println("Nope cant remove the first step");
        }
        else{
            decreaseStep();
        }
    }

    //function to add numbers and letters to the Frame which resize dynamically
    private void drawNumsAndLetters(Graphics g, Integer height, Integer width){
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.setColor(Color.darkGray);
        ArrayList letters = new ArrayList<>();
        letters.add("A");
        letters.add("B");
        letters.add("C");
        letters.add("D");
        letters.add("E");
        letters.add("F");
        letters.add("G");
        letters.add("H");

        int squareSize = 64;
        int boardSize = squareSize * 8;
        int startX = (width - boardSize) / 2;
        int startY = ((height - boardSize) / 2) + 25;

        for (int i = 0; i <=7; i++){
            int x = startX + i * squareSize + squareSize / 2 - 6; //centered above square
            int y = startY - 10;  //sightly above the board
            g.drawString(String.valueOf(letters.get(i)), x, y);
        }


        for (int i = 0; i < 8; i++) {
            int number = 8 - i;
            int x = startX - 20;  //left of the board
            int y = startY + i * squareSize + squareSize / 2 + 6;  //centered beside square
            g.drawString(String.valueOf(number), x, y);
        }
    }

    //A function to fill in the rest of the chessboard move by move with a delay
    private void startAnimation(Graphics g, ArrayList<String> moves, JPanel knightMovement) {
        int delayX = delay;
        System.out.println("TIME BEING PASSED IS"+delayX);
        Timer timer = new Timer(delayX, new ActionListener() { //0.5-second delay
            int currentStep = step; //start from the given step

            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentStep < moves.size()) {
                    System.out.println("Step is " + currentStep);
                    nextStep(g, moves, knightMovement); //move one step at a time
                    currentStep++; //increase step
                } else {
                    ((Timer) e.getSource()).stop(); //stop when done
                }
            }
        });

        timer.setInitialDelay(0); //start
        timer.start(); //begin the  tour animation
    }

    //A function that can be called to add in all 64 spaces at once - change to do all remaningin one by one
    private void addOrder(Graphics g, ArrayList moves){

        //call function to get hashmap for coords
        HashMap arrayMap = allCoords();


        //Graphics g = null;
        ////test example code
        g.setFont(new Font("Arial", Font.BOLD, 20));
        Color gold = new Color(255, 215, 0);
        g.setColor(Color.darkGray);

        //coordinates where the number will be displayed
        int x = 84; //x-coordinate(22)
        int y = 40; //y-coordinate(40)
        //int number = 42; //number to display

        for (int i = 0; i <= 64-1; i++){
            //int[] retrievedCoords = (int[]) arrayMap.get(moves.get(i));
            int[] retrievedCoords = getCoordsFromSquare((String) moves.get(i), getWidth(), getHeight());
            if (retrievedCoords == null) {
                System.err.println("Error: Coordinates not found for key: ");
                return;  //avoid further execution if no coordinates are found
            }
            ArrayList retrievedNums = new ArrayList<>();
            for (int num : retrievedCoords) {
                retrievedNums.add(num);
                //System.out.println(num);
            }
            int xCoord = (int) retrievedNums.get(0);
            int yCoord = (int) retrievedNums.get(1);
            int number = i + 1;

            for (int j=0; j <= allBlackspaces.size()-1; j++){
                //System.out.println(moves.get(step));
                //System.out.println(allBlackspaces.get(i));
                if (moves.get(i).equals(allBlackspaces.get(j))){
                    //System.out.println("//////////////////////////////////////////////////////////");
                    String colour = getSecondaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                    break;
                }
                else{
                    String colour = getPrimaryColour();
                    Color selectedColor = getColorFromName(colour);
                    g.setColor(selectedColor);
                }
            }

            g.drawString(String.valueOf(number), xCoord, yCoord);
        }
        maxStep();
    }



    //a function that creates the initail chess board
    public void displayMoves(){
        setDelayMove(500);
        JFrame frame = new JFrame("CHESS BOARD");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setSize(512,512);
        frame.setSize(800,800);
        frame.setLocation(100,100);
        frame.setLayout(new BorderLayout());

        allBlackspaces.add("B1");
        allBlackspaces.add("D1");
        allBlackspaces.add("F1");
        allBlackspaces.add("H1");

        allBlackspaces.add("A2");
        allBlackspaces.add("C2");
        allBlackspaces.add("E2");
        allBlackspaces.add("G2");

        allBlackspaces.add("B3");
        allBlackspaces.add("D3");
        allBlackspaces.add("F3");
        allBlackspaces.add("H3");

        allBlackspaces.add("A4");
        allBlackspaces.add("C4");
        allBlackspaces.add("E4");
        allBlackspaces.add("G4");

        allBlackspaces.add("B5");
        allBlackspaces.add("D5");
        allBlackspaces.add("F5");
        allBlackspaces.add("H5");

        allBlackspaces.add("A6");
        allBlackspaces.add("C6");
        allBlackspaces.add("E6");
        allBlackspaces.add("G6");

        allBlackspaces.add("B7");
        allBlackspaces.add("D7");
        allBlackspaces.add("F7");
        allBlackspaces.add("H7");

        allBlackspaces.add("A8");
        allBlackspaces.add("C8");
        allBlackspaces.add("E8");
        allBlackspaces.add("G8");



        //new testing
        //JPanel knightMovement = new JPanel();

        //panel for custom drawing
        JPanel boardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawChessBoard(g);
                g.drawImage(knightImage, knightX - 10, knightY - 35, 38, 62, this);


                int numToStep = getStep();
                HashMap arrayMap = allCoords();
                for (int i = 0; i <= numToStep; i++) {
                    int[] retrievedCoords = new int[0];
                    if(i <=63){
                        retrievedCoords = (int[]) arrayMap.get(moves.get(i));   
                    }
                    if (retrievedCoords == null) {
                        System.err.println("Error: Coordinates not found for key: ");
                        return;  //avoid further execution if no coordinates are found
                    }
                    ArrayList retrievedNums = new ArrayList<>();
                    for (int num : retrievedCoords) {
                        retrievedNums.add(num);
                        //System.out.println(num);
                    }
                    int xCoord = 0;
                    int yCoord = 0;
                    int number = 0;
                    if(i<=63){
                        xCoord = (int) retrievedNums.get(0);
                        knightX = (int) retrievedNums.get(0);
                        yCoord = (int) retrievedNums.get(1);
                        knightY = (int) retrievedNums.get(1);
                        number = i + 1;

                        for (int j = 0; j <= allBlackspaces.size() - 1; j++) {
                            //System.out.println(moves.get(step));
                            //System.out.println(allBlackspaces.get(i));
                            if (moves.get(i).equals(allBlackspaces.get(j))) {
                                //System.out.println("//////////////////////////////////////////////////////////");
                                String colour = getSecondaryColour();
                                Color selectedColor = getColorFromName(colour);
                                g.setColor(selectedColor);
                                break;
                            } else {
                                String colour = getPrimaryColour();
                                Color selectedColor = getColorFromName(colour);
                                g.setColor(selectedColor);
                            }
                        }

                    }


                    knightMovementTime = true;

                    g.drawString(String.valueOf(number), xCoord, yCoord);

                    repaint();
                }

                if (showAll == true){
                    startAnimation(g, moves, this);
                    showAll = false;
                }
                if (deleteAllBool == true){
                    //call fucntion here
                    System.out.println("Delete is being called!");
                    super.paintComponent(g);
                    drawChessBoard(g);
                    deleteAllBool = false;
                    resetStep();
                    //deleteAll(g);
                }
                if (takeNextStep == true){
                    System.out.println("Taking next step...");
                    nextStep(g, moves, this);
                    takeNextStep = false;
                }
                if (takeNextStepBackwards == true){
                    System.out.println("Going one backwards");
                    takeStepBack(g, moves);
                    takeNextStepBackwards=false;
                }
            }

            private void drawChessBoard(Graphics g){
                //set colour of background and fill the frame
                g.setColor(Color.lightGray);
                g.fillRect(0, 0, getWidth(), getHeight());

                //add in the title for the page
                g.setFont(new Font("Arial", Font.BOLD, 24));
                String colour = getPrimaryColour();
                Color selectedColor = getColorFromName(colour);
                g.setColor(selectedColor);
                String first = getFirst();
                g.drawString("Knight's Tour Solver - "+first, getWidth()/2 - 125, 75);

                //logic for board size
                boolean white = true;
                int squareSize = 64;
                int boardSize = squareSize * 8;
                int startX = (getWidth() - boardSize) / 2;
                int startY = ((getHeight() - boardSize) / 2) + 25;

                //loop through each of the chess spaces
                for(int y = 0; y < 8; y++){
                    for(int x = 0; x < 8; x++){
                        if(white==true){
                            String colourTWO = getSecondaryColour();
                            Color selectedColorTWO = getColorFromName(colourTWO);
                            g.setColor(selectedColorTWO);
                        }
                        else{
                            String colourNEW = getPrimaryColour();
                            Color selectedColorNEW = getColorFromName(colourNEW);
                            g.setColor(selectedColorNEW);
                        }
                        g.fillRect(startX + x * squareSize, startY + y * squareSize, squareSize, squareSize);
                        white = !white;
                    }
                    white = !white;
                }
                //calls other function to add in the Coordinate headers
                //System.out.println("BEFORE CALL");
                int height = getHeight();
                int width = getWidth();
                drawNumsAndLetters(g, height, width);
                //System.out.println("AFTER CALL");
            }
        };

        boardPanel.setPreferredSize(new Dimension(1024, 1024));

        //main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());
        frame.setContentPane(mainPanel);

        frame.add(boardPanel, new BorderLayout().CENTER);
        //boardPanel.setLayout(new GridLayout(8, 8));
        //frame.setVisible(true);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        //JPanel knightMovement = new JPanel();


        JButton all = new JButton("Display all");
        all.setBounds(392, 675, 150, 40);
        all.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("being called here");
                showAll = true;
                boardPanel.repaint();
            }
        });

        JButton oneForward = new JButton("Forward 1");
        oneForward.setBounds(550, 675, 60, 60);
        oneForward.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("One step forward");
                takeNextStep = true;
                boardPanel.repaint();
            }
        });

        JButton knightMovement = new JButton();
        ImageIcon knightIcon = new ImageIcon("C:\\Users\\mikey\\Documents\\Knight\'s Tour\\test\\settings.png");
        System.out.println(new File("knight.png").getAbsolutePath());
        if (knightIcon.getIconWidth() == -1 || knightIcon.getIconHeight() == -1) {
            System.out.println("Image not found or failed to load.");
        } else {
            System.out.println("Image loaded successfully!");
        }

        Image originalImage = knightIcon.getImage();
        Image scaledImage = originalImage.getScaledInstance(15, 15, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(scaledImage);

        knightMovement.setIcon(resizedIcon);
        //knightMovement.setPreferredSize(new Dimension(60, 60));
        knightMovement.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("CLICKING ON SETTINGS BUTTON");
                settings firstScreen  = new settings(moves);
                int currentDelay = getdelayMove();
                firstScreen.initialize(currentDelay);
                System.out.println("TESTING:"+firstScreen.getNewDelay());
                frame.dispose();

            }
        });


        JButton oneBackwards = new JButton("Back 1");
        oneBackwards.setBounds(180, 675, 60, 60);
        oneBackwards.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("One step backwards");
                takeNextStepBackwards = true;
                boardPanel.repaint();
            }
        });

        JButton deleteAll = new JButton("Clear Board");
        deleteAll.setBounds(250, 675, 150, 40);
        deleteAll.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("should clear all here");
                deleteAllBool = true;
                boardPanel.repaint();
            }
        });

        //add buttons to the panel
        buttonPanel.add(all);
        buttonPanel.add(oneForward);
        buttonPanel.add(knightMovement);
        buttonPanel.add(oneBackwards);
        buttonPanel.add(deleteAll);

        //add button panel to the frame
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
        frame.revalidate();
        frame.repaint();
    }

    //Main used for testing
    public static void main(String[] args) {

        try {
            FileInputStream fis = new FileInputStream("C:/Users/mikey/Documents/Knight's Tour/test/knightFive.jpg");
            knightImage = ImageIO.read(fis);
            fis.close(); //close after reading
            if (knightImage == null) {
                System.out.println("ERROR: Image could not be read.");
            } else {
                System.out.println("Image successfully loaded! Dimensions: ");
            }
        } catch (IOException e) {
            System.out.println("ERROR: Image failed to load.");
            e.printStackTrace();
        }


        ArrayList testA = new ArrayList<>();
        testA.add("A1");
        testA.add("B1");
        testA.add("C1");
        testA.add("D1");
        testA.add("E1");
        testA.add("F1");
        testA.add("G1");
        testA.add("H1");

        testA.add("A2");
        testA.add("B2");
        testA.add("C2");
        testA.add("D2");
        testA.add("E2");
        testA.add("F2");
        testA.add("G2");
        testA.add("H2");

        testA.add("A3");
        testA.add("B3");
        testA.add("C3");
        testA.add("D3");
        testA.add("E3");
        testA.add("F3");
        testA.add("G3");
        testA.add("H3");

        testA.add("A4");
        testA.add("B4");
        testA.add("C4");
        testA.add("D4");
        testA.add("E4");
        testA.add("F4");
        testA.add("G4");
        testA.add("H4");

        testA.add("A5");
        testA.add("B5");
        testA.add("C5");
        testA.add("D5");
        testA.add("E5");
        testA.add("F5");
        testA.add("G5");
        testA.add("H5");

        testA.add("A6");
        testA.add("B6");
        testA.add("C6");
        testA.add("D6");
        testA.add("E6");
        testA.add("F6");
        testA.add("G6");
        testA.add("H6");

        testA.add("A7");
        testA.add("B7");
        testA.add("C7");
        testA.add("D7");
        testA.add("E7");
        testA.add("F7");
        testA.add("G7");
        testA.add("H7");

        testA.add("A8");
        testA.add("B8");
        testA.add("C8");
        testA.add("D8");
        testA.add("E8");
        testA.add("F8");
        testA.add("G8");
        testA.add("H8");
        //displaychessBoard testCB = new displaychessBoard(testA);
        //testCB.displayMoves();
    }
}
