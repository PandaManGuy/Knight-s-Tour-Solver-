import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;



public class chessBoard {

    //Features needed for the chessBoard class to run properly - ArrayLists and HashMaps
    int numOfSpaces = 64;
    int numOfMovesLeft;
    ArrayList<String> completedMoves = new ArrayList<>();
    ArrayList<chessSpace> allSpaces;
    ArrayList<String> leftSquare = new ArrayList<>();
    ArrayList<String> leftDiamond = new ArrayList<>();
    ArrayList<String> rightSquare = new ArrayList<>();
    ArrayList<String> rightDiamond = new ArrayList<>();
    HashMap<String, String> arrayMap = new HashMap<>();
    HashMap<String, String> jumps = new HashMap<>();
    ArrayList<String> usedSpaces; //add in spaces that have been visited
    ArrayList backtracking;

    //Constructor which initializes a new chessBoard
    public chessBoard (){
        allSpaces = createSpaces();
        usedSpaces = createUsedSpaces();
        backtracking = new ArrayList<>();
        completedMoves = new ArrayList<>();  //new list every time
        numOfMovesLeft = 63;
    }

    static ArrayList createUsedSpaces(){ //create usedSpaces
        ArrayList<String> usedSpaces = new ArrayList<>();
        return usedSpaces;
    }
    void displaySpacesAndMoves() //display all spaces and moves
    {
        for(int i=0; i<=numOfSpaces-1; i++)
            System.out.println(allSpaces.get(i).displayCoord()+" - "+allSpaces.get(i).displayMoves()+" - "+allSpaces.get(i).onwardMoves);
    }

    public ArrayList<String> getCompletedMoves(){
        return completedMoves;
    }

    void setUsedSpaces(ArrayList a){
        usedSpaces = a;
        System.out.println("LIST OF USED SPACES:"+usedSpaces);

    }
    void setNumLeft(int a){
        numOfMovesLeft = a;
    }

    void updateSpaces(){
        for (int i = 0; i <= allSpaces.size() - 1; i++){
            allSpaces.get(i).addSpace(allSpaces.get(i).toString());
        }
        for (int i = 0; i <= allSpaces.size() - 1; i++){
            allSpaces.get(i).removeSpaces(usedSpaces);
        }
    }

    //testing function used to try and implement back tracking
    ArrayList backTracking(){
        //if this method is called then some level of back tracking is required
        //test for first one
        ArrayList backTrackingAttempt = (ArrayList) backtracking.get(0);
        usedSpaces = (ArrayList<String>) backTrackingAttempt.get(0);
        System.out.println("LIST OF USED SPACES:"+usedSpaces);
        String attempt = (String) backTrackingAttempt.get(1);
        int numLeft = (Integer) backTrackingAttempt.get(2);
        ArrayList returnA = new ArrayList<>();
        returnA.add(attempt);
        returnA.add(numLeft);
        return returnA;

    }
    static ArrayList createSpaces(){

        ArrayList spaces = new ArrayList<>();
        //ArrayList spaceLetters = new ArrayList<>();
//        String[] spaceCoordinates = {"A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8"};

        String[] spaceCoordinates = {
                "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8",
                "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8",
                "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8",
                "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8",
                "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8",
                "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8",
                "G1", "G2", "G3", "G4", "G5", "G6", "G7", "G8",
                "H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8"
        };

        for(String coordinate : spaceCoordinates){
            String column = coordinate.substring(0,1);
            int row = Integer.parseInt(coordinate.substring(1));

            chessSpace space = new chessSpace(row, column);
            //System.out.println("TESTLINE////////////"+space);
            space.displayCoord();
            spaces.add(space);
        }


        //System.out.println(spaces);

        return spaces;
    }

    int numOfMovesLeft(){
        return numOfMovesLeft;
    }


    //////Diamonds and Squares code from here
    public void DiamondsAndSquares(String start){
        leftSquare.add("B1");
        leftSquare.add("A3");
        leftSquare.add("C4");
        leftSquare.add("D2");
        leftSquare.add("F1");
        leftSquare.add("H2");
        leftSquare.add("G4");
        leftSquare.add("E3");
        leftSquare.add("F5");
        leftSquare.add("H6");
        leftSquare.add("G8");
        leftSquare.add("E7");
        leftSquare.add("C8");
        leftSquare.add("A7");
        leftSquare.add("B5");
        leftSquare.add("D6");

        leftDiamond.add("A1");
        leftDiamond.add("C2");
        leftDiamond.add("B3");
        leftDiamond.add("D4");
        leftDiamond.add("E1");
        leftDiamond.add("G2");
        leftDiamond.add("F3");
        leftDiamond.add("H4");
        leftDiamond.add("E5");
        leftDiamond.add("G6");
        leftDiamond.add("F7");
        leftDiamond.add("H8");
        leftDiamond.add("A5");
        leftDiamond.add("C6");
        leftDiamond.add("B7");
        leftDiamond.add("D8");

        //right square
        rightSquare.add("A2");
        rightSquare.add("C1");
        rightSquare.add("D3");
        rightSquare.add("B4");
        rightSquare.add("E2");
        rightSquare.add("G1");
        rightSquare.add("H3");
        rightSquare.add("F4");
        rightSquare.add("C5");
        rightSquare.add("D7");
        rightSquare.add("B8");
        rightSquare.add("A6");
        rightSquare.add("E6");
        rightSquare.add("G5");
        rightSquare.add("H7");
        rightSquare.add("F8");

        //right diamond

        rightDiamond.add("D1");
        rightDiamond.add("C3");
        rightDiamond.add("A4");
        rightDiamond.add("B2");
        rightDiamond.add("H1");
        rightDiamond.add("G3");
        rightDiamond.add("E4");
        rightDiamond.add("F2");
        rightDiamond.add("D5");
        rightDiamond.add("C7");
        rightDiamond.add("B6");
        rightDiamond.add("A8");
        rightDiamond.add("H5");
        rightDiamond.add("G7");
        rightDiamond.add("F6");
        rightDiamond.add("E8");

        String[] rightDiamond = {"", ""};

        //order = leftSquare, leftDiamond, rightSquare, rightDiamond
        int order = 10;
        order = setOrder(start);


        //Add in all jumps that can be made from one quadrant (NOT system) to another (e.g in left square system B1 cannot jump to any other quadrants)

        //left square
        arrayMap.put("B1", "-");
        arrayMap.put("A3", "B5");
        arrayMap.put("C4", "D6+E3");
        arrayMap.put("D2", "F1");

        arrayMap.put("F1", "D2");
        arrayMap.put("H2", "-");
        arrayMap.put("G4", "H6");
        arrayMap.put("E3", "C4+F5");

        arrayMap.put("B5", "A3");
        arrayMap.put("D6", "F5+C4");
        arrayMap.put("C8", "E7");
        arrayMap.put("A7", "-");

        arrayMap.put("F5", "E3+D6");
        arrayMap.put("H6", "G4");
        arrayMap.put("G8", "-");
        arrayMap.put("E7", "C8");


        //left diamond ones
        arrayMap.put("A1", "-");
        arrayMap.put("B3", "A5");
        arrayMap.put("C2", "E1");
        arrayMap.put("D4", "F3+C6");

        arrayMap.put("E1", "C2");
        arrayMap.put("G2", "-");
        arrayMap.put("F3", "D4+E5");
        arrayMap.put("H4", "G6");

        arrayMap.put("E5", "C6+F3");
        arrayMap.put("G6", "H4");
        arrayMap.put("F7", "D8");
        arrayMap.put("H8", "-");

        arrayMap.put("A5", "B3");
        arrayMap.put("C6", "D4+E5");
        arrayMap.put("B7", "-");
        arrayMap.put("D8", "F7");

        //right square ones
        arrayMap.put("A2", "-");
        arrayMap.put("C1", "E2");
        arrayMap.put("D3", "C5+F4");
        arrayMap.put("B4", "A6");

        arrayMap.put("E2", "C1");
        arrayMap.put("G1", "-");
        arrayMap.put("H3", "G5");
        arrayMap.put("F4", "E6+D3");

        arrayMap.put("E6", "F4+C5");
        arrayMap.put("G5", "H3");
        arrayMap.put("H7", "-");
        arrayMap.put("F8", "D7");

        arrayMap.put("A6", "B4");
        arrayMap.put("C5", "D3+E6");
        arrayMap.put("D7", "F8");
        arrayMap.put("B8", "-");

        //rightDiamond ones
        arrayMap.put("B2", "-");
        arrayMap.put("D1", "F2");
        arrayMap.put("C3", "E4+D5");
        arrayMap.put("A4", "B6");

        arrayMap.put("F2", "D1");
        arrayMap.put("H1", "-");
        arrayMap.put("G3", "H5");
        arrayMap.put("E4", "F6+C3");

        arrayMap.put("F6", "E4+D5");
        arrayMap.put("H5", "G3");
        arrayMap.put("G7", "-");
        arrayMap.put("E8", "C7");

        arrayMap.put("B6", "A4");
        arrayMap.put("D5", "C3+F6");
        arrayMap.put("C7", "E8");
        arrayMap.put("A8", "-");



        //Add in all jumps that can be made from any space into another system (e.g at the end of Left Sqaure A3 can jump to C2 and start the Left Diamond System)

        //leftSquare
        jumps.put("A3", "C2");
        jumps.put("C4", "A5");
        jumps.put("D2", "F3");
        jumps.put("B1", "-");

        jumps.put("E3", "C2");
        jumps.put("F1", "-");
        jumps.put("H2", "F3");
        jumps.put("G4", "E5");

        jumps.put("F5", "H4");
        jumps.put("H6", "F7");
        jumps.put("G8", "-");
        jumps.put("E7", "C6");

        jumps.put("B5", "D4");
        jumps.put("D6", "B7");
        jumps.put("C8", "-");
        jumps.put("A7", "C6");

        //leftdiamond
        jumps.put("A1", "-");
        jumps.put("C2", "B4");
        jumps.put("D4", "E2");
        jumps.put("B3", "C1");

        jumps.put("E1", "D3");
        jumps.put("G2", "F4");
        jumps.put("H4", "-");
        jumps.put("F3", "G1");

        jumps.put("E5", "D3");
        jumps.put("G6", "F4");
        jumps.put("H8", "-");
        jumps.put("F7", "G5");

        jumps.put("A5", "-");
        jumps.put("C6", "B4");
        jumps.put("D8", "E6");
        jumps.put("B7", "C5");

        //rightsquare
        jumps.put("A2", "C3");
        jumps.put("C1", "-");
        jumps.put("D3", "B2");
        jumps.put("B4", "D5");

        jumps.put("E2", "C3");
        jumps.put("G1", "-");
        jumps.put("H3", "F2");
        jumps.put("F4", "H5");

        jumps.put("E6", "C7");
        jumps.put("G5", "E4");
        jumps.put("H7", "F6");
        jumps.put("F8", "-");

        jumps.put("A6", "C7");
        jumps.put("C5", "A4");
        jumps.put("D7", "B6");
        jumps.put("B8", "-");

        //right diamond
        jumps.put("A4", "-");
        jumps.put("B2", "C4");
        jumps.put("D1", "E3");
        jumps.put("C3", "B5");

        jumps.put("E4", "D6");
        jumps.put("F2", "G4");
        jumps.put("H1", "-");
        jumps.put("G3", "F5");

        jumps.put("E8", "D6");
        jumps.put("F6", "G4");
        jumps.put("H5", "-");
        jumps.put("G7", "F5");

        jumps.put("A8", "-");
        jumps.put("B6", "C4");
        jumps.put("D5", "E3");
        jumps.put("C7", "B5");

        //This is the main loop which goes through each system one by one and generates a valid list of moves
        boolean completed = false;
        int max = 0;
        ArrayList arrayOfMoves = new ArrayList<>();

        //Keep looping until all 4 systems are done
        while (completed == false){

                if(max==4){
                    //The program is done
                    completed=true;
                    break;
                }

                if (order == 1){
                    if(max==4){
                        //The program is done
                        completed=true;
                        break;
                    }
                    String nextJump;
                    String next;
                    if(max == 0){
                        //Then the first value to start with is the input
                        nextJump = start;
                    }
                    else{
                        //last move is last in sequence
                        next = completedMoves.getLast();
                        //move to jump to can be found in the HashMap jumps
                        nextJump = jumps.get(next);

                    }
                    //Pass values to function which generates tour for this system
                    ArrayList test = leftSquare(nextJump, arrayMap);
                    //add to main ArrayList
                    arrayOfMoves.add(test);
                    //set new order by working out which move will be jumped to and which system it is in
                    String nextTwo = completedMoves.getLast();
                    String nextJumpTwo = jumps.get(nextTwo);
                    max++;
                    order = setOrder(nextJumpTwo);
                }


                if (order == 2){
                    if(max==4){
                        //The program is done
                        completed=true;
                        break;
                    }
                    String nextJump;
                    String next;
                    if(max == 0){
                        //Then the first value to start with is the input
                        nextJump = start;
                    }
                    else{
                        //last move is last in sequence
                        next = completedMoves.getLast();
                        //move to jump to can be found in the HashMap jumps
                        nextJump = jumps.get(next);

                    }
                    //Pass values to function which generates tour for this system
                    ArrayList testTwo = leftDiamond(nextJump, arrayMap);
                    //Add to main ArrayList
                    arrayOfMoves.add(testTwo);
                    //set new order by working out which move will be jumped to and which system it is in
                    String nextTwo = completedMoves.getLast();
                    String nextJumpTwo = jumps.get(nextTwo);
                    max++;
                    order = setOrder(nextJumpTwo);

                }
                if (order == 3){
                    if(max==4){
                        //The program is done
                        completed=true;
                        break;
                    }
                    String nextJump;
                    String next;
                    //System.out.println("max value:"+max);
                    if(max == 0){
                        //Then the first value to start with is the input
                        nextJump = start;
                    }
                    else{
                        //last move is last in sequence
                        next = completedMoves.getLast();
                        //move to jump to can be found in the HashMap jumps
                        nextJump = jumps.get(next);

                    }
                    //Pass values to function which generates tour for this system
                    ArrayList testTwo = rightSquare(nextJump, arrayMap);
                    //add to main ArrayList
                    arrayOfMoves.add(testTwo);
                    //set new order by working out which move will be jumped to and which system it is in
                    String nextTwo = completedMoves.getLast();
                    String nextJumpTwo = jumps.get(nextTwo);
                    max++;
                    order = setOrder(nextJumpTwo);

                }
                if (order == 4){
                    if(max==4){
                        //Program is done
                        completed=true;
                        break;
                    }
                    String nextJump;
                    String next;
                    if(max == 0){
                        //Then the first value to start with is the input
                        nextJump = start;
                    }
                    else{
                        //last move is last in sequence
                        next = completedMoves.getLast();
                        //move to jump to can be found in the HashMap jumps
                        nextJump = jumps.get(next);

                    }
                    //Pass values to function which generates tout for this system
                    ArrayList testTwo = rightDiamond(nextJump, arrayMap);
                    //add to main ArrayList
                    arrayOfMoves.add(testTwo);
                    //set new order by working out which move will be jumped to and which system it is in
                    String nextTwo = completedMoves.getLast();
                    String nextJumpTwo = jumps.get(nextTwo);
                    max++;
                    order = setOrder(nextJumpTwo);

                }

                if(max==4){
                    //Program is done
                    completed=true;
                }
        }
        //System.out.println("Final array of moves:"+completedMoves);
    }

    //A function which reads in a string input and compares it to the values in the different systems
    //Sets the order to correspond to the correct system
    public int setOrder(String start){
        int order = 10;
        for (int i = 0; i <=15; i++){
            if (leftSquare.get(i).equals(start)){
                //system.out.println("In left square system");
                order = 1;
            }
            if (leftDiamond.get(i).equals(start)){
                //System.out.println("In left diamond system");
                order = 2;
            }
            if (rightSquare.get(i).equals(start)){
                //System.out.println("In right square system");
                order = 3;
            }
            if (rightDiamond.get(i).equals(start)){
                //System.out.println("In right diamond system");
                order = 4;
            }
        }
        return order;
    }

    //A function for the leftSquare system
    public ArrayList leftSquare(String start, HashMap arrayMap){
        ArrayList<String> completedSegment = new ArrayList<>();
        ArrayList<String> leftSquareOneCl = new ArrayList<>();
        leftSquareOneCl.add("B1");
        leftSquareOneCl.add("D2");
        leftSquareOneCl.add("C4");
        leftSquareOneCl.add("A3");
        ArrayList<String> leftSquareTwoCl = new ArrayList<>();
        leftSquareTwoCl.add("F1");
        leftSquareTwoCl.add("H2");
        leftSquareTwoCl.add("G4");
        leftSquareTwoCl.add("E3");
        ArrayList<String> leftSquareThreeCl = new ArrayList<>();
        leftSquareThreeCl.add("F5");
        leftSquareThreeCl.add("H6");
        leftSquareThreeCl.add("G8");
        leftSquareThreeCl.add("E7");
        ArrayList<String> leftSquareFourCl = new ArrayList<>();
        leftSquareFourCl.add("B5");
        leftSquareFourCl.add("D6");
        leftSquareFourCl.add("C8");
        leftSquareFourCl.add("A7");

        //First gets the current quadrant from nextQuad
        //Then calls quadMove to generate the list of moves
        //Finally stores the jump to the next quadrant and checks it
        //Repeats until all 4 are done
        ArrayList<String> nextQuadArratlist0 = nextQuad(start, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList first = quadMove(nextQuadArratlist0, start, arrayMap, false);
        String nextQuad = (String) arrayMap.get(first.getLast());
        nextQuad = checkNextJump(nextQuad);

        ArrayList<String> nextQuadArratlist = nextQuad(nextQuad, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList second = quadMove(nextQuadArratlist, nextQuad, arrayMap, false);
        String nextQuadTwo = (String) arrayMap.get(second.getLast());
        nextQuadTwo = checkNextJump(nextQuadTwo);
        ArrayList<String> nextQuadArratlist2 = nextQuad(nextQuadTwo, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList third = quadMove(nextQuadArratlist2, nextQuadTwo, arrayMap, false);


        String nextQuadThree = (String) arrayMap.get(third.getLast());
        nextQuadThree = checkNextJump(nextQuadThree);
        ArrayList<String> nextQuadArratlist3 = nextQuad(nextQuadThree, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList fourth = quadMove(nextQuadArratlist3, nextQuadThree, arrayMap, true);

        //System.out.println(completedMoves.getLast());

        //Add all completed segments to an ArrayList and return the 16 moves
        completedSegment.add(String.valueOf(first));
        completedSegment.add(String.valueOf(second));
        completedSegment.add(String.valueOf(third));
        completedSegment.add(String.valueOf(fourth));
        return completedSegment;

    }

    public ArrayList leftDiamond(String start, HashMap arrayMap){
        ArrayList<String> completedSegment = new ArrayList<>();
        ArrayList<String> leftSquareOneCl = new ArrayList<>();
        leftSquareOneCl.add("A1");
        leftSquareOneCl.add("C2");
        leftSquareOneCl.add("D4");
        leftSquareOneCl.add("B3");
        ArrayList<String> leftSquareTwoCl = new ArrayList<>();
        leftSquareTwoCl.add("E1");
        leftSquareTwoCl.add("G2");
        leftSquareTwoCl.add("H4");
        leftSquareTwoCl.add("F3");
        ArrayList<String> leftSquareThreeCl = new ArrayList<>();
        leftSquareThreeCl.add("A5");
        leftSquareThreeCl.add("C6");
        leftSquareThreeCl.add("D8");
        leftSquareThreeCl.add("B7");
        ArrayList<String> leftSquareFourCl = new ArrayList<>();
        leftSquareFourCl.add("E5");
        leftSquareFourCl.add("G6");
        leftSquareFourCl.add("H8");
        leftSquareFourCl.add("F7");


        //First gets the current quadrant from nextQuad
        //Then calls quadMove to generate the list of moves
        //Finally stores the jump to the next quadrant and checks it
        //Repeats until all 4 are done
        ArrayList<String> nextQuadArratlist0 = nextQuad(start, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList first = quadMove(nextQuadArratlist0, start, arrayMap, false);
        String nextQuad = (String) arrayMap.get(first.getLast());
        nextQuad = checkNextJump(nextQuad);

        ArrayList<String> nextQuadArratlist = nextQuad(nextQuad, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList second = quadMove(nextQuadArratlist, nextQuad, arrayMap, false);
        String nextQuadTwo = (String) arrayMap.get(second.getLast());
        nextQuadTwo = checkNextJump(nextQuadTwo);
        ArrayList<String> nextQuadArratlist2 = nextQuad(nextQuadTwo, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList third = quadMove(nextQuadArratlist2, nextQuadTwo, arrayMap, false);

        String nextQuadThree = (String) arrayMap.get(third.getLast());
        nextQuadThree = checkNextJump(nextQuadThree);
        ArrayList<String> nextQuadArratlist3 = nextQuad(nextQuadThree, leftSquareOneCl, leftSquareTwoCl, leftSquareThreeCl, leftSquareFourCl);
        ArrayList fourth = quadMove(nextQuadArratlist3, nextQuadThree, arrayMap, true);

        //System.out.println(completedMoves.getLast());

        //Add all completed segments to an ArrayList and return the 16 moves
        completedSegment.add(String.valueOf(first));
        completedSegment.add(String.valueOf(second));
        completedSegment.add(String.valueOf(third));
        completedSegment.add(String.valueOf(fourth));
        return completedSegment;

    }

    public ArrayList rightSquare(String start, HashMap arrayMap){
        ArrayList<String> completedSegment = new ArrayList<>();
        ArrayList<String> rightSquareOneCl = new ArrayList<>();
        rightSquareOneCl.add("C1");
        rightSquareOneCl.add("D3");
        rightSquareOneCl.add("B4");
        rightSquareOneCl.add("A2");
        ArrayList<String> rightSquareTwoCl = new ArrayList<>();
        rightSquareTwoCl.add("G1");
        rightSquareTwoCl.add("H3");
        rightSquareTwoCl.add("F4");
        rightSquareTwoCl.add("E2");
        ArrayList<String> rightSquareThreeCl = new ArrayList<>();
        rightSquareThreeCl.add("G5");
        rightSquareThreeCl.add("H7");
        rightSquareThreeCl.add("F8");
        rightSquareThreeCl.add("E6");
        ArrayList<String> rightSquareFourCl = new ArrayList<>();
        rightSquareFourCl.add("C5");
        rightSquareFourCl.add("D7");
        rightSquareFourCl.add("B8");
        rightSquareFourCl.add("A6");


        //First gets the current quadrant from nextQuad
        //Then calls quadMove to generate the list of moves
        //Finally stores the jump to the next quadrant and checks it
        //Repeats until all 4 are done
        ArrayList<String> nextQuadArratlist0 = nextQuad(start, rightSquareOneCl, rightSquareTwoCl, rightSquareThreeCl, rightSquareFourCl);
        ArrayList first = quadMove(nextQuadArratlist0, start, arrayMap, false);
        String nextQuad = (String) arrayMap.get(first.getLast());
        nextQuad = checkNextJump(nextQuad);

        ArrayList<String> nextQuadArratlist = nextQuad(nextQuad, rightSquareOneCl, rightSquareTwoCl, rightSquareThreeCl, rightSquareFourCl);
        ArrayList second = quadMove(nextQuadArratlist, nextQuad, arrayMap, false);
        String nextQuadTwo = (String) arrayMap.get(second.getLast());
        nextQuadTwo = checkNextJump(nextQuadTwo);
        ArrayList<String> nextQuadArratlist2 = nextQuad(nextQuadTwo, rightSquareOneCl, rightSquareTwoCl, rightSquareThreeCl, rightSquareFourCl);
        ArrayList third = quadMove(nextQuadArratlist2, nextQuadTwo, arrayMap, false);

        String nextQuadThree = (String) arrayMap.get(third.getLast());
        nextQuadThree = checkNextJump(nextQuadThree);
        ArrayList<String> nextQuadArratlist3 = nextQuad(nextQuadThree, rightSquareOneCl, rightSquareTwoCl, rightSquareThreeCl, rightSquareFourCl);
        ArrayList fourth = quadMove(nextQuadArratlist3, nextQuadThree, arrayMap, true);

        //System.out.println(completedMoves.getLast());

        //Add all completed segments to an ArrayList and return the 16 moves
        completedSegment.add(String.valueOf(first));
        completedSegment.add(String.valueOf(second));
        completedSegment.add(String.valueOf(third));
        completedSegment.add(String.valueOf(fourth));
        return completedSegment;
    }

    public ArrayList rightDiamond(String start, HashMap arrayMap){
        ArrayList<String> completedSegment = new ArrayList<>();
        ArrayList<String> rightDiamondOneCl = new ArrayList<>();
        rightDiamondOneCl.add("B2");
        rightDiamondOneCl.add("D1");
        rightDiamondOneCl.add("C3");
        rightDiamondOneCl.add("A4");
        ArrayList<String> rightDiamondTwoCl = new ArrayList<>();
        rightDiamondTwoCl.add("F2");
        rightDiamondTwoCl.add("H1");
        rightDiamondTwoCl.add("G3");
        rightDiamondTwoCl.add("E4");
        ArrayList<String> rightDiamondThreeCl = new ArrayList<>();
        rightDiamondThreeCl.add("F6");
        rightDiamondThreeCl.add("H5");
        rightDiamondThreeCl.add("G7");
        rightDiamondThreeCl.add("E8");
        ArrayList<String> rightDiamondFourCl = new ArrayList<>();
        rightDiamondFourCl.add("B6");
        rightDiamondFourCl.add("D5");
        rightDiamondFourCl.add("C7");
        rightDiamondFourCl.add("A8");

        //First gets the current quadrant from nextQuad
        //Then calls quadMove to generate the list of moves
        //Finally stores the jump to the next quadrant and checks it
        //Repeats until all 4 are done
        ArrayList<String> nextQuadArratlist0 = nextQuad(start, rightDiamondOneCl, rightDiamondTwoCl, rightDiamondThreeCl, rightDiamondFourCl);
        ArrayList first = quadMove(nextQuadArratlist0, start, arrayMap, false);
        String nextQuad = (String) arrayMap.get(first.getLast());
        nextQuad = checkNextJump(nextQuad);

        ArrayList<String> nextQuadArratlist = nextQuad(nextQuad, rightDiamondOneCl, rightDiamondTwoCl, rightDiamondThreeCl, rightDiamondFourCl);
        ArrayList second = quadMove(nextQuadArratlist, nextQuad, arrayMap, false);
        String nextQuadTwo = (String) arrayMap.get(second.getLast());
        nextQuadTwo = checkNextJump(nextQuadTwo);
        ArrayList<String> nextQuadArratlist2 = nextQuad(nextQuadTwo, rightDiamondOneCl, rightDiamondTwoCl, rightDiamondThreeCl, rightDiamondFourCl);
        ArrayList third = quadMove(nextQuadArratlist2, nextQuadTwo, arrayMap, false);

        String nextQuadThree = (String) arrayMap.get(third.getLast());
        nextQuadThree = checkNextJump(nextQuadThree);
        ArrayList<String> nextQuadArratlist3 = nextQuad(nextQuadThree, rightDiamondOneCl, rightDiamondTwoCl, rightDiamondThreeCl, rightDiamondFourCl);
        ArrayList fourth = quadMove(nextQuadArratlist3, nextQuadThree, arrayMap, true);

        //System.out.println(completedMoves.getLast());

        //Add all completed segments to an ArrayList and return the 16 moves
        completedSegment.add(String.valueOf(first));
        completedSegment.add(String.valueOf(second));
        completedSegment.add(String.valueOf(third));
        completedSegment.add(String.valueOf(fourth));
        return completedSegment;
    }

    //A function which reads in a String and checks if it stores one or two coordinates split by +
    public String checkNextJump(String nextQuad){
        //split by + and add to arraylist
        String[] input = nextQuad.split("\\+");

        ArrayList parts = new ArrayList<>();
        for (String part : input){
            parts.add(part);
        }

        //if more than one found
        if (parts.size() > 1){
            ArrayList sortedParts = new ArrayList<>();
            for (int i =0; i < parts.size(); i++){
                boolean found = false;
                //loop through each coordinate and chack against currently done coordinates
                for(int j = 0; j < completedMoves.size(); j++){
                    if(parts.get(i).equals(completedMoves.get(j))){
                        //System.out.println("FOUND AN ANOMALY HERE - DO NOT ADD");
                        found = true;
                    }
                }
                //only add to sorted parts if not already in the tour
                if(!found){
                    sortedParts.add(parts.get(i));
                }

            }
            //At this point sortedParts either contains the only valid move or two valid moves (if neither have already been made)
            //SO just return the first one - no impact on the tour
            return (String) sortedParts.get(0);
        }
        //if only one coordinate found so just return it
        else{
            return nextQuad;
        }
    }

    //A function which reads in a coordinate and 4 quadrants represented as ArrayLists and returns the correct quadrant ArrayList
    public ArrayList nextQuad(String nextQuad, ArrayList leftSquareOneCl, ArrayList leftSquareTwoCl, ArrayList leftSquareThreeCl, ArrayList leftSquareFourCl){

        ArrayList<String> nextQuadArratlist = new ArrayList<>();
        for(int i = 0; i <=3; i++){
            if(leftSquareOneCl.get(i).equals(nextQuad)){
                nextQuadArratlist = leftSquareOneCl;

            }
            if(leftSquareTwoCl.get(i).equals(nextQuad)){
                nextQuadArratlist = leftSquareTwoCl;

            }
            if(leftSquareThreeCl.get(i).equals(nextQuad)){
                nextQuadArratlist = leftSquareThreeCl;

            }
            if(leftSquareFourCl.get(i).equals(nextQuad)){
                nextQuadArratlist = leftSquareFourCl;

            }
        }
        return nextQuadArratlist;

    }

    //A function that reads in an ArrayList of 4 coords, a starting coordinate and other info and returns the correct order
    public ArrayList quadMove(ArrayList moves, String start, HashMap arrayMap, Boolean islastQuad){

        //if it is the last quadrant then it is a special case - no concerns about the last space
        if(islastQuad==true){
            //set clockwise
            ArrayList test = setClockwise(moves, start);
            //if the last move can jump to any other space - then done
            if(jumps.get(test.getLast()) != "-"){
                for (int i = 0; i<= test.size()-1; i++){
                    completedMoves.add((String) test.get(i));
                }
                return test;

            }
            else{//cannot jump to next system so need to reverse the spaces (will work)
                ArrayList test2 = setCounterClockwise(test, start);
                jumps.get(test2.getLast());

                //add to completed and return
                for (int i = 0; i<= test2.size()-1; i++){
                    completedMoves.add((String) test2.get(i));
                }
                return test2;
            }
        }

        else{ //not last quadrant so final move matters - need to jump to next quadrant
            ArrayList test = setClockwise(moves, start);
            String last = (String) test.getLast();
            String hahsmapOutput = (String) arrayMap.get(last);
            hahsmapOutput = checkNextJump(hahsmapOutput);
            //System.out.println("Move to jump to:"+hahsmapOutput);
            //if hashmap value of test is not - and a valid move then that quadrant can be jumped to
            boolean completedMovesBool = false;

            //checks if move to jump to has already been made
            if(completedMoves.size()==0){
                completedMovesBool = true;
            }
            else{
                for (String move: completedMoves){
                    if(move.equals(hahsmapOutput)){
                        completedMovesBool = false;
                        break;
                    }
                    else{
                        completedMovesBool = true;
                    }
                }
            }

            //if hahsmapOutput is - or completedMovesBool == false then it is not a valid move
            if(hahsmapOutput.equals("-") || completedMovesBool == false){
                //NOT VALID MOVE - rotate
                ArrayList test2 = setCounterClockwise(test, start);

                //return correct list
                for (int i = 0; i<= test2.size()-1; i++){
                    completedMoves.add((String) test2.get(i));
                }
                return test2;

            }
            else{//is a valid move and the four moves can be made with a jump to hahsmapOutput
                for (int i = 0; i<= test.size()-1; i++){
                    completedMoves.add((String) test.get(i));
                }
                return test;
            }
        }
    }

    //takes input of 4 positions, a start position and returns the list with it shifted along so
    //that start is at index 0
    public ArrayList setClockwise(ArrayList leftSquareOneCl, String start){
        int coordsStart = 0;
        ArrayList<String> newLeftSquareOneCl = new ArrayList<>();
        for (Object coords: leftSquareOneCl){
            if(coords.equals(start)){
                break;
            }
            else{
                coordsStart++;
            }
        }
        for (int i = coordsStart; i <=3; i++){
            newLeftSquareOneCl.add((String) leftSquareOneCl.get(i));
        }
        for (int i = 0; i <= coordsStart-1; i++){
            newLeftSquareOneCl.add((String) leftSquareOneCl.get(i));
        }
        return newLeftSquareOneCl;

    }

    //takes input of 4 positions, a start position and returns the list with it shifted along so
    //that start is at index 0
    public ArrayList setCounterClockwise(ArrayList leftSquareOneCC, String start){
        ArrayList<String> newLeftSquareOneCC = new ArrayList<>();
        newLeftSquareOneCC.add(start);
        newLeftSquareOneCC.add((String) leftSquareOneCC.get(3));
        newLeftSquareOneCC.add((String) leftSquareOneCC.get(2));
        newLeftSquareOneCC.add((String) leftSquareOneCC.get(1));
        return newLeftSquareOneCC;

    }

    /////////End of Diamonds and Squares
    /////////Warnsdorffs Algorithm Below

    //Main function of the algorithm which takes in a space and calculates the next best onward move
    public String startPosition(String currentSpace){
        usedSpaces.add(currentSpace); //adds current space to a list of unavailable moves
        int currentI = 0;
        int possibleMoves = 0;
        ArrayList<String> potentialMoves = null;

        //removes current space from all possible moves
        for (int i=0; i<=allSpaces.size()-1; i++){
            allSpaces.get(i).removeSpaces(usedSpaces);
        }

        //find currentSpace chessSpace and access info needed - list of onwards moves and store in potentialMoves
        for (int i=0; i<=allSpaces.size()-1; i++){
            if (Objects.equals(allSpaces.get(i).displayCoord(), currentSpace)){
                //System.out.println("Forward moves from current space: "+allSpaces.get(i).moves);
                currentI = i;
                possibleMoves = allSpaces.get(i).onwardMoves;
                potentialMoves = allSpaces.get(i).moves;
                //make arraylist of right size here
            }
        }

        //debugging line to output possible moves
        //System.out.println("Possible moves from "+ allSpaces.get(currentI).displayCoord()+" are:"+potentialMoves);

        if (potentialMoves.size() == 1){
            //final move being made
            numOfMovesLeft--;
            return potentialMoves.get(0);
        }

        //create a hashmap and arraylists to store info on how many moves each move can make
        HashMap<String, Integer> onwardsMovesMoves = new HashMap<String, Integer>();
        ArrayList<String> coordsEachPossibleMove = new ArrayList<>();
        ArrayList<Integer> numOfMovesInEachPossibleMove = new ArrayList<>();

        //store all data into the hashmap and arraylists
        for (int i = 0; i<= (potentialMoves).size()-1; i++){//cycle through each Space //int j=0; j<= allSpaces.size()-1; j++
            for (int j=0; j<= allSpaces.size()-1; j++){//cycle through each chessSpace
                if (Objects.equals(potentialMoves.get(i), allSpaces.get(j).displayCoord())){
                    //System.out.println("TESTING SPACE:"+allSpaces.get(j).displayCoord());
                    int OnwardsMoves = allSpaces.get(j).onwardMoves;
                    //System.out.println("SPACE: "+allSpaces.get(j).displayCoord()+" has: "+OnwardsMoves); //debugging line
                    //coordsEachPossibleMove.add(allSpaces.get(j).displayCoord());
                    numOfMovesInEachPossibleMove.add(OnwardsMoves);
                    onwardsMovesMoves.put(allSpaces.get(j).displayCoord(), OnwardsMoves);
                }
            }
        }

        //debugging lines
        //System.out.println("Potential Moves: "+potentialMoves);
        //System.out.println("Num of each possible: "+numOfMovesInEachPossibleMove);
        //System.out.println("List of used spaces"+usedSpaces);

        //Now use hashmap onwardsMoves to figure out what the lowest number of moves is (may be draw)
        int lowest = 9; //none can have more than 8
        ArrayList<String> coordsOfPossibleLowest = new ArrayList<>();
        for (int j=0; j <= numOfMovesInEachPossibleMove.size()-1; j++){
            if (numOfMovesInEachPossibleMove.get(j) == 0){
                //This should never be reached
                System.out.println("ERROR");
            }
            else if (numOfMovesInEachPossibleMove.get(j) <= lowest){
                lowest=numOfMovesInEachPossibleMove.get(j);
            }

        }

        //System.out.println("Lowest should be lowest value now:"+lowest); //debugging line


        //cycle through and draw out lowest values
        for (int i = 0; i <= numOfMovesInEachPossibleMove.size()-1; i++){
            if (numOfMovesInEachPossibleMove.get(i) == 0){
                System.out.println("0 found here, WARNING");
                continue;
            }
            //if stored number of moves is less than or equal to stored lowest then it is a possibility
            //System.out.println(onwardsMovesMoves.get(i));
            else if (numOfMovesInEachPossibleMove.get(i) <= lowest){//HERE numOfMovesInEachPossibleMove.get(i) != 0
                //System.out.println("NEW POSSIBLE LOWEST:"+potentialMoves.get(i));
                lowest=numOfMovesInEachPossibleMove.get(i);
                coordsOfPossibleLowest.add(potentialMoves.get(i));
            }
        }

        //at this point we have an arraylist coordsOfPossibleLowest that stores all the potential moves from our
        //position. If it has one item that it is that move - if it has more than one then we need to call a tiebreaker
        //and call the algorithm again

        if (coordsOfPossibleLowest.size() == 1){
            //Only one possible move - make this move
            //System.out.println("After calculating possible moves from "+currentSpace+" looks like "+coordsOfPossibleLowest.get(0)+" is the next move");
            //System.out.println("//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
            numOfMovesLeft = numOfMovesLeft - 1;
            return coordsOfPossibleLowest.get(0);
        }
        else{
            //Multiple possible moves so call the tie breaker
            //System.out.println("Possible moves are "+coordsOfPossibleLowest+" each with "+lowest);
            //System.out.println("Calling the tie breaker...");
            //System.out.println("//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////");
            String nextMove = tieBreaker(coordsOfPossibleLowest, lowest);
            numOfMovesLeft = numOfMovesLeft - 1;
            return nextMove;
        }
    }

    //function which returns the onward moves from a certain space
    ArrayList onwardsMovesFromCoord(String coords){
        ArrayList<String> allMovesFromCoord = new ArrayList<>();
        for (int i = 0; i<= (allSpaces).size()-1; i++){//cycle through each Space
            if (Objects.equals(coords, allSpaces.get(i).displayCoord())){
                allMovesFromCoord = allSpaces.get(i).moves;

            }
        }
        return allMovesFromCoord;
    }

    //function that returns the number of onward moves from a certain space
    Integer numberOfOnwardMoves(String coords){
        int numberOfOnwardMoves = 0;

        for (int i = 0; i<= (allSpaces).size()-1; i++){//cycle through each Space
            if (Objects.equals(coords, allSpaces.get(i).displayCoord())){
                numberOfOnwardMoves = allSpaces.get(i).onwardMoves;

            }
        }
        //cannot go back to space it came from
        numberOfOnwardMoves = numberOfOnwardMoves - 1;
        return numberOfOnwardMoves;

    }

    //the tieBreaker function which works out the correct onward move
    String tieBreaker(ArrayList coordsOfPossibleLowest, Integer lowest){
        ArrayList <Integer> sumofOnwardMoves = new ArrayList<>();

        //for each iteration of coordsPossibleLowest... pass Coords to function that return arraylist of which onwards moves it has
        for (int i =0; i <= coordsOfPossibleLowest.size()-1; i++){
            ArrayList<String> allOnwardMoves = onwardsMovesFromCoord((String) coordsOfPossibleLowest.get(i));
            //now for each one of these get there number of onward moves and
            int totalNum = 0;
            for (int j=0; j<= allOnwardMoves.size()-1; j++){
                int thisInstance = numberOfOnwardMoves(allOnwardMoves.get(j));
                totalNum = totalNum + thisInstance;
            }
            sumofOnwardMoves.add(totalNum);
        }

        //if lowest value in sum of onward moves here then we have a tiebreaker sorted
        int lowestSum = 1000;
        for (int i = 0; i <=sumofOnwardMoves.size()-1; i++){
            if (sumofOnwardMoves.get(i) <= lowestSum){
                lowestSum = sumofOnwardMoves.get(i);
            }
        }

        //lowestSum is now equal to the lowest
        ArrayList<String> finalPossibleMoves = new ArrayList<>();

        //if equal to lowest add in the corresponding coordinates
        for (int i = 0; i <= sumofOnwardMoves.size()-1; i++){
            if (sumofOnwardMoves.get(i) == lowestSum){
                finalPossibleMoves.add((String) coordsOfPossibleLowest.get(i));
            }
        }


        if(finalPossibleMoves.size() == 1){
            //only one move stored so it must be this one
            return finalPossibleMoves.get(0);
        }
        else{
            //still more than one stored so pick randomly
            int randomInt = (int) (Math.random() * (finalPossibleMoves.size()));
            String notTaken = finalPossibleMoves.get(Math.abs(randomInt-1));

            //Back tracking inital implemenation
            ArrayList backtrackingTest = new ArrayList<>();
            ArrayList usedSpacesBT = usedSpaces;
            backtrackingTest.add(usedSpacesBT);
            backtrackingTest.add(notTaken);
            backtrackingTest.add(numOfMovesLeft);
            backtracking.add(backtrackingTest);

            return finalPossibleMoves.get(randomInt);
        }
    }

    //testing function which is never used
    int sumOfOnwardsMoves(String coords){
        usedSpaces.add(coords);
        for (int i=0; i<=allSpaces.size()-1; i++){
            allSpaces.get(i).removeSpaces(usedSpaces);
        }

        ArrayList<String> moves = new ArrayList<>();
        for (int i=0; i<=allSpaces.size()-1; i++){
            if (Objects.equals(allSpaces.get(i).displayCoord(), coords)){
                System.out.println("Found it here: "+allSpaces.get(i).moves);
                moves = allSpaces.get(i).moves;
            }
        }

        System.out.println("Coords of all onwards moves are:"+moves);

        int total = 0;

        //cycle back through and extract the number of onwards moves each of those have adding to total
        for (int i = 0; i<= (moves).size()-1; i++){//cycle through each move
            for (int j=0; j<= allSpaces.size()-1; j++){//cycle through each chessSpace
                if (Objects.equals(moves.get(i), allSpaces.get(j).displayCoord())){
                    System.out.println("Match found!");
                    System.out.println(allSpaces.get(j).onwardMoves);
                    System.out.println(allSpaces.get(j).moves);
                    total = total + allSpaces.get(j).onwardMoves;
                }
            }
        }
        System.out.println("sum of all onwards moves from "+moves+" is "+total);
        usedSpaces.remove(coords);
        for (int i=0; i<=allSpaces.size()-1; i++){
            allSpaces.get(i).addSpace(coords);
        }
        return total;
    }

    ////////End of Warnsdorff's Algorithm

    /*public static void main(String[] args) throws IOException { //Main for testing Warnsdorff's Algorithm and Diamonds and Squares
        //Create BufferedWriter for CSV output (initialized once before the loop)
        BufferedWriter writer = new BufferedWriter(new FileWriter("warnsdorffOutput.csv"));
        writer.write("Coordinate,Run number,Tour Success or Failure");
        writer.newLine();
        writer.flush();

        int successes = 0;
        int failures = 0;

        for (int i = 1; i <= 1000; i++) {
            long startTime = System.nanoTime();
            System.out.println("\nRun #" + (i));
            chessBoard testingBoard = new chessBoard();
            ArrayList<String> testingCompletedMoves = new ArrayList<>();
            try {
                String origin = "H8";

                char fileChar = origin.charAt(0); //'E'
                int rank = Character.getNumericValue(origin.charAt(1)); //2
                int y = 9 - rank; //9 - 2 = 7
                origin = String.valueOf(fileChar) + String.valueOf(y);
                //System.out.println("TESTING-"+origin);

                String first = testingBoard.startPosition(origin);
                testingCompletedMoves.add(origin);
                testingCompletedMoves.add(first);

                while (testingBoard.numOfMovesLeft() > 0) {
                    String nextCoord = testingCompletedMoves.get(testingCompletedMoves.size() - 1);
                    String nextMove = testingBoard.startPosition(nextCoord);
                    testingCompletedMoves.add(nextMove);
                }

                //System.out.println(testingCompletedMoves);

                if (testingCompletedMoves.size() == 64) {
                    successes++;
                    System.out.println("Success! Completed all 64 moves.");
                } else {
                    failures++;
                    System.out.println("Incomplete tour. Only reached " + testingCompletedMoves.size() + " moves.");
                }

            } catch (Exception e) {
                failures++;
                System.out.println("An error occurred during the knight's tour: " + e.getMessage());
                e.printStackTrace();
            }
            long endTime = System.nanoTime();
            long duration = (endTime - startTime); //milliseconds


            if (!testingCompletedMoves.isEmpty()) {
                boolean worked = testingCompletedMoves.size() == 64;
                String outputLine = testingCompletedMoves.get(0) + "," + i + "," + worked + "," + duration + "," + testingCompletedMoves;
                writer.write(outputLine);
                writer.newLine();
                writer.flush();
                System.out.println("ATTEMPTING TO ADD: " + outputLine);
            } else {
                System.out.println("No moves completed, skipping CSV write for run #" + i);
            }
        }
        //close the file writer after all runs are done
        writer.close();
        System.out.println("Output written to warnsdorffOutput.csv");
        System.out.println("Writing to: " + new File("warnsdorffOutput.csv").getAbsolutePath());

        System.out.println("Successes: " + successes);
        System.out.println("Failures: " + failures);
        System.out.println("Reached the end of main");

    }*/


    public static void main(String[] args) throws IOException { //Main for testing Warnsdorff's Algorithm and Diamonds and Squares

        int successes = 0;
        int failures = 0;
        BufferedWriter writer = new BufferedWriter(new FileWriter("diamondsAndSquaresOutput.csv"));
        writer.write("Coordinate,Run number,Tour Success or Failure,Tour");
        writer.newLine();
        writer.flush();
        for (char file = 'A'; file <= 'H'; file++) {
            for (int rank = 1; rank <= 8; rank++) {
                for (int i = 1; i <= 100; i++) {
                    long startTime = System.nanoTime();
                    System.out.println("\nRun #" + (i));
                    chessBoard testingBoard = new chessBoard();
                    ArrayList<String> testingCompletedMoves = new ArrayList<>();
                    String origin = "";
                    try {
                        int y = 9 - rank;
                        origin = String.valueOf(file) + y;
                        //System.out.println("TESTING-"+origin);
                        //System.out.println(origin);
                        testingBoard.DiamondsAndSquares(origin);
                        System.out.println(testingBoard.getCompletedMoves());
                        successes++;


                    } catch (Exception e) {
                        System.out.println("An error occurred during the knight's tour: " + e.getMessage());
                        e.printStackTrace();
                        failures++;
                    }
                    long endTime = System.nanoTime();
                    long duration = (endTime - startTime); //milliseconds

                    boolean worked = testingBoard.getCompletedMoves().size() == 64;
                    String outputLine = i + "," + origin + "," + worked + "," + duration + "," + "\"" + testingBoard.getCompletedMoves() + "\",";
                    writer.write(outputLine);
                    writer.newLine();
                    writer.flush();
                    System.out.println("ATTEMPTING TO ADD: " + outputLine);


                }

            }
        }

















        //Warsndorff's Algorithm testing code
        /*//create BufferedWriter for CSV output (initialized once before the loop)
        BufferedWriter writer = new BufferedWriter(new FileWriter("warnsdorffOutput.csv"));
        writer.write("Coordinate,Run number,Tour Success or Failure");
        writer.newLine();
        writer.flush();

        int successes = 0;
        int failures = 0;
        for (char file = 'A'; file <= 'H'; file++) {
            for (int rank = 1; rank <= 8; rank++) {
                for (int i = 1; i <= 100; i++) {
                    long startTime = System.nanoTime();
                    System.out.println("\nRun #" + (i));
                    chessBoard testingBoard = new chessBoard();
                    ArrayList<String> testingCompletedMoves = new ArrayList<>();
                    try {
                        int y = 9 - rank;
                        String origin = String.valueOf(file) + y;
                        //System.out.println("TESTING-"+origin);

                        String first = testingBoard.startPosition(origin);
                        testingCompletedMoves.add(origin);
                        testingCompletedMoves.add(first);

                        while (testingBoard.numOfMovesLeft() > 0) {
                            String nextCoord = testingCompletedMoves.get(testingCompletedMoves.size() - 1);
                            String nextMove = testingBoard.startPosition(nextCoord);
                            testingCompletedMoves.add(nextMove);
                        }

                        //System.out.println(testingCompletedMoves);

                        if (testingCompletedMoves.size() == 64) {
                            successes++;
                            System.out.println("Success! Completed all 64 moves.");
                        } else {
                            failures++;
                            System.out.println("Incomplete tour. Only reached " + testingCompletedMoves.size() + " moves.");
                        }

                    } catch (Exception e) {
                        failures++;
                        System.out.println("An error occurred during the knight's tour: " + e.getMessage());
                        e.printStackTrace();
                    }
                    long endTime = System.nanoTime();
                    long duration = (endTime - startTime);


                    if (!testingCompletedMoves.isEmpty()) {
                        boolean worked = testingCompletedMoves.size() == 64;
                        String outputLine = i + "," + testingCompletedMoves.get(0) + "," + worked + "," + duration + "," + "\"" + testingCompletedMoves + "\",";
                        writer.write(outputLine);
                        writer.newLine();
                        writer.flush();
                        System.out.println("ATTEMPTING TO ADD: " + outputLine);
                    } else {
                        System.out.println("No moves completed, skipping CSV write for run #" + i);
                    }
                }

            }
        }
        //close the file writer after all runs are done
        writer.close();
        System.out.println("Output written to warnsdorffOutput.csv");
        System.out.println("Writing to: " + new File("warnsdorffOutput.csv").getAbsolutePath());
        System.out.println("Successes: " + successes);
        System.out.println("Failures: " + failures);
        System.out.println("Reached the end of main");*/

    }

}
