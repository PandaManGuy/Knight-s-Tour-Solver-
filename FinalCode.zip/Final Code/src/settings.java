import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class settings {

    public ArrayList moves;

    private static JTextField inputField;

    public String newDelay;

    public String getNewDelay(){
        return newDelay;
    }

    public settings(ArrayList InputMoves) {
        moves = InputMoves;
    }


    public void initialize(int delay){
        //add in all here
        //JFrame for settings
        JFrame inputFrame = new JFrame("Settings");
        inputFrame.setSize(800,500);
        inputFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        inputFrame.setLayout(new GridBagLayout()); //use GridBagLayout for centering

        //A text field for user input
        inputField = new JTextField(10);
        inputField.setFont(new Font("Arial", Font.PLAIN, 16));
        inputField.setHorizontalAlignment(JTextField.CENTER);
        inputField.setText(String.valueOf(delay));

        //Label for title
        JLabel title = new JLabel("Settings", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 25));

        //Label for heading
        JLabel headerOne = new JLabel("Time Delay between moves in ms", SwingConstants.CENTER);
        headerOne.setFont(new Font("Arial", Font.BOLD, 15));

        //Label for heading
        JLabel headerTwo = new JLabel("Colour Scheme", SwingConstants.CENTER);
        headerTwo.setFont(new Font("Arial", Font.BOLD, 15));

        String[] options = {"Black and White", "Blue and Red", "Orange and Yellow"};
        JComboBox<String> comboBox = new JComboBox<>(options);

        //submit button
        JButton submitButton = new JButton("Save Settings");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        //if the button is clicked
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userInput = inputField.getText().trim();
                System.out.println("Time delay being updated from "+delay+"to "+userInput);
                newDelay = userInput;
                System.out.println("The new delay is"+newDelay);
                String selectedOption = (String) comboBox.getSelectedItem();
                System.out.println("The new Colour scheme is: " + selectedOption);
                String[] partsOfColours = selectedOption.split("\\s+");
                String primaryColour = partsOfColours[0];
                String secondaryColour = partsOfColours[2];
                System.out.println("Primary C is"+primaryColour);
                System.out.println("Sec C is"+secondaryColour);
                primaryColour = primaryColour.toLowerCase();
                secondaryColour = secondaryColour.toLowerCase();
                //call new displaychessBoard with updated values
                displaychessBoard display = new displaychessBoard(moves, Integer.parseInt(newDelay),primaryColour,secondaryColour);
                display.displayMoves();
                inputFrame.dispose();
            }
        });


        //GridBagConstraints to move content around the frame

        //GridBagConstraints
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(-200, 0, 0, 0);

        //GridBagConstraints
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.gridx = 0;
        gbc2.gridy = 5;
        gbc2.insets = new Insets(10, 0, 10, 0);

        //GridBagConstraints
        GridBagConstraints gbc3 = new GridBagConstraints();
        gbc3.gridx = 0;
        gbc3.gridy = 2;
        gbc3.fill = GridBagConstraints.HORIZONTAL;
        gbc3.insets = new Insets(5, 0, 10, 0);

        //GridBagConstraints
        GridBagConstraints gbc4 = new GridBagConstraints();
        gbc4.gridx = 0;
        gbc4.gridy = 1;
        gbc4.fill = GridBagConstraints.HORIZONTAL;
        gbc4.insets = new Insets(5, 0, 2, 0);

        //GridBagConstraints
        GridBagConstraints gbc5 = new GridBagConstraints();
        gbc5.gridx = 0;
        gbc5.gridy = 3;
        gbc5.fill = GridBagConstraints.HORIZONTAL;
        gbc5.insets = new Insets(5, 0, 2, 0);

        //GridBagConstraints
        GridBagConstraints gbc6 = new GridBagConstraints();
        gbc6.gridx = 0;
        gbc6.gridy = 4;
        gbc6.fill = GridBagConstraints.HORIZONTAL;
        gbc6.insets = new Insets(5, 0, 2, 0);

        inputFrame.add(title, gbc);
        inputFrame.add(submitButton, gbc2);
        inputFrame.add(headerOne, gbc4);
        inputFrame.add(headerTwo, gbc5);
        inputFrame.add(comboBox, gbc6);
        inputFrame.add(inputField, gbc3);
        inputFrame.setVisible(true);
    }
}
