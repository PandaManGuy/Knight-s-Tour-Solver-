import java.util.ArrayList;
import java.util.Arrays;

//This is the second method to solve the Knight's Tour in this program - The Diamonds and Squares technique
//Declared as a seperate class

public class diamondsSquares {
    public String start;

    public ArrayList<String> sequence = new ArrayList<>();

    public diamondsSquares(String start) {
        this.start = start;
        //this.leftSquare = null;
        System.out.println("TESTING");

        System.out.println("BEINGT CALLESD FROM HERE");

        chessBoard diamondsAndSquaresChessboard = new chessBoard();
        diamondsAndSquaresChessboard.displaySpacesAndMoves(); //outputs spaces and onwards moves
        diamondsAndSquaresChessboard.DiamondsAndSquares(start);
        sequence = diamondsAndSquaresChessboard.getCompletedMoves();

        //work out which system in and call method
        //String x = leftSystem(start);


    }

    public ArrayList<String> getSequence(){
        return sequence;
    }

    public String leftSystem(String start){
        String[] B1 = {"A3", "D2"};
        String[] A3 = {"B1", "C4", "B5"};
        String[] C4 = {"D2", "A3", "E3", "D6"};
        String[] D2 = {"B1", "C4", "F1"};
        //for each if you can move to 0 or 1 do that and else move to 2/3 if available
        ArrayList<String> leftSquareOne = new ArrayList<>();
        leftSquareOne.add("B1");
        leftSquareOne.add(Arrays.toString(B1));
        leftSquareOne.add("A3");
        leftSquareOne.add(Arrays.toString(A3));
        leftSquareOne.add("C4");
        leftSquareOne.add(Arrays.toString(C4));
        leftSquareOne.add("D2");
        leftSquareOne.add(Arrays.toString(D2));
        for (int i = 0; i <= 7; i = i + 2){
            //System.out.println("TESTING");
            //System.out.println(leftSquareOne.get(i));
            if(start.equals(leftSquareOne.get(i))){
                System.out.println("Found this:"+leftSquareOne.get(i));
            }
        }
        return "A";
    }


    public static void main(String[] args) {
        String start = "D4";//D2//E3 //D1
        diamondsSquares testD = new diamondsSquares(start);
    }
}
