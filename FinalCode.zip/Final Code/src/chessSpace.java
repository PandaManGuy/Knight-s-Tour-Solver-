//This is the chessSpace class which allows for each space to be modelled as its own object

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class chessSpace {
    int spaceNumber; //(1-8)
    String spaceLetter; //(A-H)
    public ArrayList<String> moves; //An arraylist of moves that can be made from the current space
    public ArrayList<String> unavailableMoves; //An arraylist of moves that can no longer be made from the current space
    int onwardMoves; //The number of onward moves which is the length of Arraylist moves
    static final HashMap<String, Integer> ABC = new HashMap<>(); //Added as part of Experiment One - HashMap to store coordinates
    static final HashMap<Integer, String> NUM_TO_LETTER = new HashMap<>(); //Added as part of Experiment One
    static {
        ABC.put("A", 1);
        ABC.put("B", 2);
        ABC.put("C", 3);
        ABC.put("D", 4);
        ABC.put("E", 5);
        ABC.put("F", 6);
        ABC.put("G", 7);
        ABC.put("H", 8);

        for (Map.Entry<String, Integer> entry : ABC.entrySet()) {
            NUM_TO_LETTER.put(entry.getValue(), entry.getKey());
        }
    }
    //Returns current valid moves
    ArrayList displayMoves(){
        return moves;
    }


    //Testing function - Prints out the number of current moves
    void displayNumMoves(){
        System.out.println(onwardMoves);
    }

    //Testing function - Returns the current coordinates in a string format
    String displayCoord(){
        String coords = (spaceLetter+spaceNumber);
        return coords;
    }

    //A constructor which when called assigns the Number and Letter and then calls the algorithm checkMoves
    //After it returns all onward moves the length of the ArrayList can be stored as onwardMoves and a new Arraylist for unavailableMoves is created
    public chessSpace (int thisspaceNumber, String thisspaceLetter){//Takes input of a valid Number and Letter
        spaceNumber = thisspaceNumber;
        spaceLetter = thisspaceLetter;
        moves = checkMoves(spaceNumber, spaceLetter);
        onwardMoves = moves.size();
        unavailableMoves = new ArrayList<>();
    }


    //This is a function which is used to 'remove' certain moves from the ArrayList of moves that can still be made
    //As the Knight's Tour runs more and more moves will become unavailable as they have already been visited
    public void removeSpaces(ArrayList<String> usedSpaces){ //Takes ArrayList of usedSpaces as input
        for (int i = 0; i<= (usedSpaces).size()-1; i++){ //For each inputted usedSpace
            for (int j=0; j<= moves.size()-1; j++){//For each stored move in this chessSpace

                //Check to see if they match
                if (Objects.equals(usedSpaces.get(i), moves.get(j))){
                    moves.remove(String.valueOf(usedSpaces.get(i))); //remove the now invalid move from moves
                    onwardMoves = onwardMoves - 1; //reduce number of moves by one
                    unavailableMoves.add(usedSpaces.get(i)); //add now unavailable move to unavialableMoves
                }
            }
        }
    }


    //A testing function which adds invalid moves back to the valid moves Arraylist
    public void addSpace(String space){
        for (int i=0; i<= unavailableMoves.size()-1; i++){
            if (Objects.equals(space, unavailableMoves.get(i))){
                moves.add(space);
                onwardMoves = onwardMoves + 1;
            }
        }
    }

    //The function which is called to get the valid moves for a specific space
    static ArrayList checkMoves(int spaceNumber, String spaceLetter)
    {
        ArrayList<String> potentialMoves = new ArrayList<String>();
        //Calls actual function
        potentialMoves = outputPossibleMoves(spaceNumber, spaceLetter);

        return potentialMoves;
    }


    //Key function for this Class which takes in the spaces coordinates and then works out all onward moves for it
    static ArrayList outputPossibleMoves(int num, String letter){
        //HashMap<String, Integer> ABC = new HashMap<String, Integer>();//hashMap for calculations - removed for E1
        //ABC.put("A", 1);
        //ABC.put("B", 2);
        //ABC.put("C", 3);
        //ABC.put("D", 4);
        //ABC.put("E", 5);
        //ABC.put("F", 6);
        //ABC.put("G", 7);
        //ABC.put("H", 8);

        //a knight can make at most 8 moves from a starting position and the moves can be defined as pairs with two spaces above being the 'up' moves
        //loop through these pairs checking for their validity and add them to ArrayList moves
        ArrayList<String> moves = new ArrayList<String>();

        //check UP
        if ((num > 2)){ //two up and then one left or right - both is possible
            int letterValue = ABC.get(letter); //Retrieve other coordinate for further calculations

            //if lettervalue = 1 or 8 then on edge of board
            if (letterValue == 1){ //Cannot move up and to the left but can go up and to the right
                letterValue = letterValue + 1;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }
                possibleChar = NUM_TO_LETTER.get(letterValue);

                //Decrease the num by 2 (moving two up)
                int possibleNum = num - 2;
                //System.out.println("Move one is "+possibleChar+possibleNum);
                moves.add(possibleChar+possibleNum); //add new valid move to moves
            }
            else if (letterValue == 8){
                //can only make move 1
                letterValue = letterValue - 1;
                String possibleChar = "";
//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }
                possibleChar = NUM_TO_LETTER.get(letterValue);
                int possibleNum = num - 2;
                //System.out.println("Move two is "+possibleChar+possibleNum);
                moves.add(possibleChar+possibleNum);
            }
            else{
                //in middle of board and can make both moves potentially
                int firstLetterValue = letterValue;
                String possibleCharOne = "";
                int secondLetterValue = letterValue;
                String possibleCharTwo = "";
                firstLetterValue = firstLetterValue + 1;
                secondLetterValue = secondLetterValue - 1;

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharOne = NUM_TO_LETTER.get(firstLetterValue);
                int possibleNumOne = num - 2;
                //System.out.println("Move one is "+possibleCharOne+possibleNumOne);
                moves.add(possibleCharOne+possibleNumOne);

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharTwo = NUM_TO_LETTER.get(secondLetterValue);
                int possibleNumTwo = num - 2;
                //System.out.println("Move two is "+possibleCharTwo+possibleNumTwo);
                moves.add(possibleCharTwo+possibleNumTwo);
            }
        }
        else{
            //System.out.println("No possible moves above");
        }

        //check RIGHT
        int letterValue = ABC.get(letter);
        if ((letterValue <= 6)){ //potential moves to the right
            letterValue = ABC.get(letter);

            //calculations for just 2 right and 1 down
            if (num == 1){
                //only do 2 across and one down
                letterValue = letterValue + 2;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValue);
                int possibleNum = num + 1;
                moves.add(possibleChar+possibleNum);

            }
            //calculations for 2 right and 1 up
            else if (num == 8){
                //only do 2 across and one up
                letterValue = letterValue + 2;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValue);
                int possibleNum = num - 1;
                moves.add(possibleChar+possibleNum);
            }
            //calculations to check for both
            else{
                //can do both moves
                int firstLetterValue = letterValue;
                String possibleCharOne = "";
                int secondLetterValue = letterValue;
                String possibleCharTwo = "";
                firstLetterValue = firstLetterValue + 2;
                secondLetterValue = secondLetterValue + 2;

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharOne = NUM_TO_LETTER.get(firstLetterValue);
                int possibleNumOne = num + 1;
                moves.add(possibleCharOne+possibleNumOne);

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharTwo = NUM_TO_LETTER.get(secondLetterValue);
                int possibleNumTwo = num - 1;
                moves.add(possibleCharTwo+possibleNumTwo);
            }

        }
        else{
            //System.out.println("Nope...");
        }

        //check DOWN
        //same basic calculations as example above but for 2 down and 1 left or right
        if ((num <= 6)){
            //two up and then one left or right - both is possible
            letterValue = ABC.get(letter);
            //if lettervalue = 1 or 8 then on edge of board
            if (letterValue == 1){
                letterValue = letterValue + 1;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValue);
                int possibleNum = num + 2;
                moves.add(possibleChar+possibleNum);
            }
            else if (letterValue == 8){
                letterValue = letterValue - 1;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValue);
                int possibleNum = num + 2;
                moves.add(possibleChar+possibleNum);
            }
            else{
                //in middle of board and can make both moves potentially
                int firstLetterValue = letterValue;
                String possibleCharOne = "";
                int secondLetterValue = letterValue;
                String possibleCharTwo = "";
                firstLetterValue = firstLetterValue + 1;
                secondLetterValue = secondLetterValue - 1;

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharOne = NUM_TO_LETTER.get(firstLetterValue);
                int possibleNumOne = num + 2;
                moves.add(possibleCharOne+possibleNumOne);

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharTwo = NUM_TO_LETTER.get(secondLetterValue);
                int possibleNumTwo = num + 2;
                moves.add(possibleCharTwo+possibleNumTwo);
            }

        }
        else{
            //System.out.println("No possible moves below");
        }

        //check LEFT
        int letterValueLeft = ABC.get(letter);
        if ((letterValueLeft >= 3)) {
            if (num == 1) {
                //only do 2 across and one down
                letterValueLeft = letterValueLeft - 2;
                String possibleChar = "";

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValueLeft);
                int possibleNum = num + 1;
                moves.add(possibleChar+possibleNum);

            } else if (num == 8) {
                //only do 2 across and one up

                letterValueLeft = letterValueLeft - 2;
                String possibleChar = "";

                //Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleChar = NUM_TO_LETTER.get(letterValueLeft);
                int possibleNum = num - 1;
                moves.add(possibleChar+possibleNum);
            } else {
                //can do both moves left

                int firstLetterValue = letterValueLeft;
                String possibleCharOne = "";
                int secondLetterValue = letterValueLeft;
                String possibleCharTwo = "";
                firstLetterValue = firstLetterValue - 2;
                secondLetterValue = secondLetterValue - 2;

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharOne = NUM_TO_LETTER.get(firstLetterValue);
                int possibleNumOne = num - 1;
                moves.add(possibleCharOne+possibleNumOne);

//Removed for Experiment One
//                //Retrieve the new Character from the hashMap
//                if (ABC.containsValue(letterValue)){
//                    for (Map.Entry<String, Integer> entry: ABC.entrySet()){
//                        if (Objects.equals(entry.getValue(), letterValue)){
//                            possibleChar = entry.getKey();
//                        }
//                    }
//                }

                possibleCharTwo = NUM_TO_LETTER.get(secondLetterValue);
                int possibleNumTwo = num + 1;
                moves.add(possibleCharTwo+possibleNumTwo);
            }
        }
        return moves;
    }

    //Main used for testing
    public static void main(String[] args) {
        System.out.println("Main - Experiment One");
        String[] letters = {"A", "B", "C", "D", "E", "F", "G", "H"};
        //Loop through each row and column to create a chessSpace
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("chessSpacesOutput.csv"));

            for (String letter : letters) {
                for (int number = 1; number <= 8; number++) {
                    for (int run = 1; run <= 10; run++) {
                        long startTime = System.nanoTime();

                        chessSpace space = new chessSpace(number, letter);

                        long endTime = System.nanoTime();
                        long duration = (endTime - startTime); //milliseconds

                        //output line
                        String outputLine = run + "," +
                                space.displayCoord() + "," +
                                "\"" + space.displayMoves() + "\"," +
                                duration + "," +
                                space.onwardMoves + "\n";

                        writer.write(outputLine);
                    }
                }
            }
            writer.close();
            System.out.println("Output written to chessSpacesOutput.txt");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}
