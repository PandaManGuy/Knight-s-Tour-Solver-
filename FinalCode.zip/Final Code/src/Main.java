//This is the main executable part of the program
//It reads in a space from the user, computes a tour and the visually displays it
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Main {
    static final HashMap<String, Integer> ABC = new HashMap<>();
    static {
        ABC.put("A", 1);
        ABC.put("B", 2);
        ABC.put("C", 3);
        ABC.put("D", 4);
        ABC.put("E", 5);
        ABC.put("F", 6);
        ABC.put("G", 7);
        ABC.put("H", 8);
    }
    static ArrayList<String> spaces = new ArrayList<String>();

    public static void main(String[] args) {

        //System.out.println("This is the Knights Tour Solver program");

        chessBoard theBoard = new chessBoard();
        //this makes a chess board with 64 spaces and each space is represented as the object ChessSpace
        //each chess space knows its possible onwards moves and the number of these
        theBoard.displaySpacesAndMoves(); //outputs spaces and onwards moves

        displayInput firstScreen  = new displayInput();
        firstScreen.initialize();

        synchronized (firstScreen) {
            while (firstScreen.getStart() == null) {
                try {
                    firstScreen.wait();  //wait for the user to click the button
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        String start = firstScreen.getStart();
        char fileChar = start.charAt(0); //'E'
        int rank = Character.getNumericValue(start.charAt(1)); //2

        //Adjust rank
        int y = 9 - rank; //9 - 2 = 7
        System.out.println("HERE");
        System.out.println(fileChar);
        System.out.println(y);
        System.out.println(String.valueOf(fileChar) + String.valueOf(y));
        start = String.valueOf(fileChar) + String.valueOf(y);




        System.out.println("Starting position: " + start);


        //System.out.println("The knight's tour will now begin - enter your starting space (e.g A1, C5 etc) : ");
        Scanner scanner = new Scanner(System.in);
        //String start = startSearch;

        String[] allStart = {
                "A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1",
                "A2", "B2", "C2", "D2", "E2", "F2", "G2", "H2",
                "A3", "B3", "C3", "D3", "E3", "F3", "G3", "H3",
                "A4", "B4", "C4", "D4", "E4", "F4", "G4", "H4",
                "A5", "B5", "C5", "D5", "E5", "F5", "G5", "H5",
                "A6", "B6", "C6", "D6", "E6", "F6", "G6", "H6",
                "A7", "B7", "C7", "D7", "E7", "F7", "G7", "H7",
                "A8", "B8", "C8", "D8", "E8", "F8", "G8", "H8"
        };

        boolean valid = false;
        for (String position: allStart){
            System.out.println(start);
            System.out.println(position);
            if (start.equals(position)){
                valid = true;
            }
        }

        String start2 = "";
        int count = 0;
        while (valid==false){
            count++;
            System.out.println("ERROR - enter your starting space (e.g A1, C5 etc) : ");
            start2 = scanner.nextLine();

            for (String position: allStart){
                if (start2.equals(position)){
                    valid = true;
                    break;
                }
            }

        }

        if(count != 0){
            start = start2;
        }


        System.out.println("Starting space is "+start);

        ////////////////////////////////////test code


        ArrayList<String> listOfMoves = new ArrayList<>(); //actual output of the program
        ArrayList<String> moves = new ArrayList<>(); //actual output of the program - D AND S
        //int maxRetries = 50;  //max number of retries before giving up
        int retries = 0;

        try {
            listOfMoves.add(start);
            String first = theBoard.startPosition(start);
            System.out.println("MOVE IS: " + first);
            listOfMoves.add(first);
            System.out.println("WARNSDORFF");

            while (theBoard.numOfMovesLeft() > 0) {
                System.out.println(theBoard.numOfMovesLeft() + " example here");

                String nextCoord = listOfMoves.get(listOfMoves.size() - 1);
                String nextMove = theBoard.startPosition(nextCoord);

                listOfMoves.add(nextMove);
                System.out.println(listOfMoves.size() + ": " + listOfMoves);

            }
        } catch (Exception e) {

            System.out.println("Let's try the other method...DIAMONDS AND SQUARES");
            //diamondsSquares testD = new diamondsSquares(start);
            chessBoard dandsBBoard = new chessBoard();
            dandsBBoard.DiamondsAndSquares(start);
            moves = dandsBBoard.getCompletedMoves();
            System.out.println("DIAMONDS AND SQAURES");
        }

        //from here we should have a completed board of 64 moves/coords
        //e.g - [A1, C2, A3, B1, D2, F1, H2, G4, H6, G8, E7, C8, A7, B5, C7, A8, B6, A4, B2, D1, E3, G2, E1, F3, H4, G6, H8, F7, D8, B7, A5, C4, D6, E8, G7, F5, G3, H1, F2, H3, G1, E2, C1, A2, C3, D5, F4, H5, F6, H7, G5, E4, C5, B3, D4, E6, F8, D7, B8, A6, B4, D3, E5, C6]


        ArrayList<String> finalListOfMoves = new ArrayList<>();
        if (moves.size() == 0){
            finalListOfMoves = listOfMoves;
        }
        else{
            finalListOfMoves = moves;
        }

        String black = "black";
        String white = "white";


        displaychessBoard display = new displaychessBoard(finalListOfMoves, 500, black, white);//listOfMoves
        display.displayMoves();

        }
    }
